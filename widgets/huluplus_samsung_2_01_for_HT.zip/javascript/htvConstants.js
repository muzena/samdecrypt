//  HULU CONFIDENTIAL MATERIAL. DO NOT DISTRIBUTE.
//  Copyright (C) 2009-2010 Hulu, LLC
//  All Rights Reserved
/**
 * htvConstants.js
 * 
 * Contains constants used throughout the app.
 */
/*jslint nomen: false, debug: true, evil: false, immed: false, plusplus: false*/


var $htv;


$htv.Constants = function () {
    return {
        CSEL_SALT: "yumUsWUfrAPraRaNe2ru2exAXEfaP6Nugubepreb68REt7daS79fase9haqar9sa",
        CSEL_KEY: "4878B22E76379B55C962B18DDBC188D82299F8F52E3E698D0FAF29A40ED64B21",
        CSEL_S: "FqBzsDe7qi98DJwnYTmDqFLk2LRHtsDb",
        CONFIG_PATH: "https://play.hulu.com/config",
        DEFAULT_PAGE_SIZE: 25,
        SITE_SEC: $htv.Platform.properties.site_sec,
        SITE_APP: $htv.Platform.properties.site_app,
        MENU_PREFIX: "htv_",    // used to increment Twinkie menu versions
        TEST_AD_URL: "http://ll.a.hulu.com/published/IO105329/02_Trailer_SPT_Operation_h264_Hulu_Mezz_24fps389825_4x3_30fps_H264_650K.flv",
        CONTROLS_PEEK_DURATION: ($htv.Platform.properties.has_animations ? 2500 : 3000),      // Standard peek duration for pressing up/down
        ACTIVE_PEEK_DURATION: ($htv.Platform.properties.has_animations ? 5000 : 6000),        // Peek duration for when the user is actively navigating (i.e. _qualityButton)
        PAUSED_PEEK_DURATION: ($htv.Platform.properties.has_animations ? 8000 : 10000),       // How long controls are visible when paused
        AD_FREE_SEEK_PERIOD: 15000         // Number of milliseconds of content the user is able to view without having to watch an ad after seeking past an ad break.
    };
}();

$htv.Constants.Endpoints = {
    reportGeocheckURL: "http://www.hulu.com/report-geocheck",
    kinko: "http://ib.huluim.com",
    api: "http://www.hulu.com/api/1.0",
    pb_tracker: "http://www.hulu.com/pt",
    iball: "http://ib.huluim.com",
    sapi: "https://secure.hulu.com/api/1.0",
    csel: "http://s.hulu.com",
    pb_autoresume_timeout: 120000,
    asset: "http://assets.huluim.com",
    pb_interval: 30000,
    activateCodeURL: "www.hulu.com/activate",
    plusInviteURL: "http://www.hulu.com/service_unavailable.html",
    mrkt_img: "http://assets.huluim.com/downloads/marketing-back-2.jpg",
    hide_help_videos: true,
    rt_beacon: "http://t.hulu.com",
    disable_geocheck: false,
    key_expiration: 2677,
    beacon: "http://t2.hulu.com",
    userAccountURL: "http://www.hulu.com/profile",
    key: "",
    requestInviteURL: "www.hulu.com/invite",
    masthead: "http://www.hulu.com/home/featured/ipad.xml?device=living_room",
    third_party_beacon_platform: "TV",
    geok_response: "allowed",
    search: "http://r.hulu.com/ipad_search",
    forgotPasswordURL: "http://www.hulu.com/users/forgot_password",
    menu: "http://m.hulu.com",
    key_id: 42,
    plusLandingURL: "http://www.hulu.com/plus"
};
