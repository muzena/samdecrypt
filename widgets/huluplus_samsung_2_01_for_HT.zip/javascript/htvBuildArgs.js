
/**
 * htvBuildArgs.js
 * 
 * Contains constants generated at build time.
 */
/*jslint nomen: false, debug: true, evil: false, immed: false, plusplus: false*/

var $htv;

$htv.BuildArgs = function () {
    return {
        revision: 75380
    };
}();
