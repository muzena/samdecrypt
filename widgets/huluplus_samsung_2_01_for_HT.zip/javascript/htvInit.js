//  HULU CONFIDENTIAL MATERIAL. DO NOT DISTRIBUTE.
//  Copyright (C) 2009-2010 Hulu, LLC
//  All Rights Reserved
$htv = {};
$htv.Libs = {};

// moved widgetAPI to where it's used in attachEventHandlers
var tvKey = new Common.API.TVKeyValue();
