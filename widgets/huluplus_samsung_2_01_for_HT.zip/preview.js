﻿/**
 * @author Samsung
 */
