#!/bin/sh
# emergency skript exit to prevent boot loop
      for USB in ${1:- \
         /dtv/usb/sd* } ; do
         echo "checking $USB"
         sleep 1
         if [ -e $USB/STOP_SAMYGO ]; then
            "STOP found. Script exit..."
            exit 1
         fi
      done
cd /tmp
mkdir /tmp/bin
/mtd_exe/InfoLink/lib/unzip -o -P 12345 /mtd_rwcommon/widgets/user/SamyGO/data/data.zip -d /tmp/bin/
chmod 777 /tmp/bin/*
/tmp/bin/busybox --install -s /tmp/bin
sync
export PATH=/tmp/bin:$PATH
export LD_LIBRARY_PATH=/tmp/bin:$LD_LIBRARY_PATH
sync
/tmp/bin/busybox tcpsvd -vE 0.0.0.0 21 /tmp/bin/busybox ftpd -w / &
/tmp/bin/remshd33 & #remshd shell on 33 port from now!
sync

ln -s /dev/loop3 /tmp/loopnone
sync
/tmp/bin/busybox losetup /tmp/loopnone  /mtd_rwcommon/widgets/user/SamyGO/data/samyext4.img
/tmp/bin/busybox mount -o sync,exec /tmp/loopnone /mnt 
/tmp/bin/busybox --install -s /mnt/bin
sync  

cd / && /sbin/rmmod ARS_module > /dev/null 2>&1
echo " " >> /mnt/sam.log 2>&1
echo "===========================" >> /mnt/sam.log 2>&1
echo "ls -la after rmmod ARS_module" >> /mnt/sam.log 2>&1
echo "===========================" >> /mnt/sam.log 2>&1
ls -la /mnt/* >> /mnt/sam.log 2>&1
echo "===========================" >> /mnt/sam.log 2>&1
echo "Starting rcSGO from run1.sh" >> /mnt/sam.log 2>&1
echo "===========================" >> /mnt/sam.log 2>&1
/mnt/bin/busybox sh -x /mnt/rcSGO /mnt >> /mnt/sam.log 2>&1

echo " " >> /mnt/sam.log 2>&1
echo "===========================" >> /mnt/sam.log 2>&1
echo "Starting UEP_killer.sh" >> /mnt/sam.log 2>&1
echo "===========================" >> /mnt/sam.log 2>&1
/tmp/bin/UEP_killer.sh &

ps | grep run.sh | grep -v grep | while read child_pid others
do
    echo "Killing child process $child_pid of run.sh"
    kill -9 $child_pid
done  