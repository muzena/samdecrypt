#!/bin/sh

sh -x /mtd_rwcommon/widgets/user/SamyGO/data/run1.sh >> /mtd_rwcommon/sam.log  2>&1