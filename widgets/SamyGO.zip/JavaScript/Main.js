var Main = {  }

var widgetAPI = new Common.API.Widget();        
var tvKey = new Common.API.TVKeyValue();

var runf1=1;
var runf2=1;
var LabelString="Log:<br>";
var usbPlugin;
var FilePlugin;
var nUSBCount = 0;
var commonFilePath;

Main.onLoad = function() 
{             
    alert("Main.onLoad()");
    this.enableKeys();
    widgetAPI.sendReadyEvent();             
    Func();
};

Main.onUnload = function()
{

};

Main.enableKeys = function()
{
	document.getElementById("anchor").focus();
};

Main.keyDown = function() 
{            
    var keyCode = event.keyCode;

	switch(keyCode)
	{
		case tvKey.KEY_RETURN:
		case tvKey.KEY_PANEL_RETURN:
			widgetAPI.sendReturnEvent();
			break;
	/*	case tvKey.KEY_RED:
			if(runf2==1) 
				{
				 runf2=0;
				 Log ("<br>Please Wait 20-30 sec....");
				 setTimeout("Func1(commonFilePath);",3000);
				}
			 else Log('Activated yet!');
			break;
	*/		
		case tvKey.KEY_ENTER:
		case tvKey.KEY_PANEL_ENTER:
		 if(nUSBCount < 1) Log('USB not found!');	 
		   else	if(runf1==1)
			     {
				  runf1=0;
				  Log ("<br>Please Wait  5-10 sec....");
				  setTimeout("Func1(commonFilePath);",3000);
			     }	
			     else Log('Activated yet!');
			
			break;
		default:
			alert("Unhandled key");
			break;
	} 
};

function Log(Str)
{
	var Label = document.getElementById("LogLabel");
	LabelString = LabelString+Str+"<br>";
	widgetAPI.putInnerHTML(Label,LabelString);
};

function sleep(ms) 
{
	ms += new Date().getTime();
	while (new Date() < ms){}
};

function Func() 
{
	usbPlugin = document.getElementById("pluginStorage");
	FilePlugin = document.getElementById("pluginObjectFile");
	nUSBCount = eval("usbPlugin.GetUSBListSize()");
	var Param;
	var r1=0;
	var r2=0;
	var r3=0;

	if(nUSBCount < 0) nUSBCount = 0;
	Log("Found <b style='font-size:30px; color:green'>" + nUSBCount + "</b> USB devices");
    for (var i = 0; i < nUSBCount; i++)
    {
        var nid1 = eval("usbPlugin.GetUSBDeviceID("+i+")");
        var nid = parseInt(nid1);
        var VN = "<br>Vendor Name = <b style='color:green'>" + eval("usbPlugin.GetUSBVendorName("+nid+")") + "</b>";
        var MN = "<br>Model Name = <b style='color:green'>" + eval("usbPlugin.GetUSBModelName("+nid+")") + "</b>";
        nPartition = eval("usbPlugin.GetUSBPartitionNum("+nid+")");
        for (var j = 0; j < nPartition; j++) 
        {
        	var mntPath = eval("usbPlugin.GetUSBMountPath("+nid+", "+j+")");
            commonFilePath = '/dtv/usb/' + mntPath; 

            //Param = "FilePlugin.IsExistedPath(commonFilePath + '/data/SamyGO.zip')";
            r1 = 1;//eval(Param);
            Param = "FilePlugin.IsExistedPath(commonFilePath + '/data/AutoStart')"; 
            r2 = eval(Param);
            Param = "FilePlugin.IsExistedPath(commonFilePath + '/data/libSkype.so')"; 
            r3 = eval(Param);
            if (r1 == 1 && r2 == 1 && r3 == 1)
            	{
            		Log("The activation files found on USB: " + commonFilePath + VN + MN);
            		return;
            	}
              else 
            	{
          			Log("Some activation files not found on USB: " + commonFilePath + VN + MN);
          			return;
            	}
        }
       Log("The activation files not found on USB: error");
    }   
};

function Func1(Path) 
{

	var r=0;
	var Param;
	var str =''; 
	
    Param="FilePlugin.Copy ('"+ Path +"/data/AutoStart','/mtd_rwcommon/moip/engines/Skype/AutoStart')";
    r = eval(Param);
    if (r==1) str = 'OK'; else str = 'No';
    Log("Step1: " + str)

    Param="FilePlugin.Copy ('"+ Path +"/data/libSkype.so','/mtd_rwcommon/moip/engines/Skype/libSkype.so')";
    r = eval(Param);
    if (r==1) str = 'OK'; else str = 'No';
    Log("Step2: " + str);

  /*  if(runf2==1)
     {
      Param="FilePlugin.Unzip('"+ Path +"/InstallSamygo/data/SamyGO.zip','/mtd_rwcommon/widgets/user/SamyGO/')";
      r = eval(Param);
      if (r==1) str = 'OK'; else str = 'No';
      Log("Step3: " + str);
     } 
   */  
    Log("Now press exit and restart tv");	
};