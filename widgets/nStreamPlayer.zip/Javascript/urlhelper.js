﻿var UrlHelper ={plugin : null}


UrlHelper.init = function()
{
	return true;
}

UrlHelper.parse_url = function(url)
{
	var result_url = url;

	if ((url.indexOf("vk.com") > 0) || (url.indexOf("/vkontakte.php?video") > 0) || (url.indexOf("vkontakte.ru/video_ext.php") > 0) || (url.indexOf("/vkontakte/vk_kinohranilishe.php?id=") > 0))
	{
		var responseText = API.Request(url);
		responseText = API.XHRObj.responseText;
		video_host = parser(responseText, "var video_host = '", "'");
		video_uid = parser(responseText, "var video_uid = '", "'");
		video_vtag = parser(responseText, "var video_vtag = '", "'");
		video_no_flv = parser(responseText, "video_no_flv =", ";");
		video_max_hd = parser(responseText, "var video_max_hd = '", "'");
		alert("video_no_flv " + video_no_flv);
		if (video_no_flv == 1) {
			switch (video_max_hd) {
				case "0": fname = "240.mp4"; break;
				case "1": fname = "360.mp4"; break;
				case "2": fname = "480.mp4"; break;
				case "3": fname = "480.mp4"; break;
			}
			result_url = video_host + "u" + video_uid + "/video/" + video_vtag + "." + fname;
		}
		else {
			vkid = parser(responseText, "vkid=", "&");
			fname = "vk.flv";
			result_url = "http://" + video_host + "/assets/videos/" + video_vtag + vkid + "." + fname;
		}
	}

	if (url.indexOf("youtube.com/watch?v=") > 0)
	{	
		var video_id = url.substr(url.indexOf('=')+1);
		alert('result_url ' + video_id);
		result_url = getBestQuality(video_id);

	}
	
	if (url.indexOf("http://www.megavideo.com")==0)
	{
		API.active_url = "http://www.megavideo.com/xml/videolink.php"+url.substr(25),1;
		API.Request(API.active_url);
		resp = API.XHRObj;
		result_url = parseXml_MegaVideo(resp);
	}	

	try
	{
		result_url = gosha_parser(result_url);
	} catch(e){
		alert("no func found "+e);
	}
	return result_url;
}


function parser(str, left, right) { 
       var res = '';
       var tmp = str; 
       var i = tmp.indexOf(left);
        if ( i > 0 )   {
            tmp = tmp.substr(i + left.length);
            i = tmp.indexOf(right);
            if ( i > 0 )   res = tmp.substr(0, i);
        }
    return res;    
}

RegExp.escape = function (text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
}

function getBestQuality(videoID) {
		
		xhr=new XMLHttpRequest();

		var param_array = new Array('&el=embedded', '&el=detailpage', '&el=vevo', '');
					
		var txtDoc = "";
		for(var i = 0; i < param_array.length; ++i)
		{
			var param = param_array[i];

			var send_to_url = 'http://www.youtube.com/get_video_info?&video_id=' + videoID + param + '&ps=default&eurl=&gl=US&hl=en';
			xhr.open("GET", send_to_url, false);
			xhr.setRequestHeader("Accept-Encoding", "identity");
			xhr.setRequestHeader("Accept-Language", "en-us,en;q=0.5");
			xhr.setRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			xhr.setRequestHeader("User-Agent", "Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6");
			xhr.setRequestHeader("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
			xhr.setRequestHeader("Connection", "close");

			xhr.send();
			
			txtDoc=xhr.responseText;
			//alert('send_to_url ' + send_to_url)
			//alert('xtDoc ' + xhr.status)
			//alert("responseText: " + txtDoc);
			//alert(txtDoc.indexOf('fmt_url_map'));
			if(txtDoc.indexOf('fmt_url_map'))
			{
				break;
			}
			
			if(txtDoc.indexOf('url_encoded_fmt_stream_map'))
			{
				break;
			}
		}

		xhr.destroy();
		
		var paare = txtDoc.split("&");
/*
	    -- flv
	    flv_240p =  '5',
	    flv_360p = '34',
	    flv_480p = '35',
	    -- mp4
	     mp4_360p = '18',
	     mp4_720p = '22',
	    mp4_1080p = '37',
	    mp4_3072p = '38',
	    -- webm
	    webm_480p = '43',
	    webm_720p = '45',
	    -- 3gp, use 'tgp' since lua won't accept '3gp'
	    tgp_144p  = '17
*/
		var paar, name, wert;
		var params=new Array();
		for (var i = 0; i < paare.length; i++) {
			paar = paare[i].split("=");
			name = paar[0];
			wert = paar[1];
			params[name] = unescape(wert);
		}
		var url ="";

		if(params['fmt_url_map'])
		{

			var test = params['fmt_url_map'].split(",");
			
			for (var index = 0; index < test.length; index++)
			{
				var videoinfo = test[index].split("|");

				if (videoinfo[0] == '37')
				{
					url = videoinfo[1];
					alert(videoinfo[0]);
					alert("HD 1080p");
					break;				
				}
				if (videoinfo[0] == '22')
				{
					url = videoinfo[1];
					alert(videoinfo[0]);
					alert("HD 720p");
					break;
				}
			}
		}		

		if(params['url_encoded_fmt_stream_map'])
		{
			alert('url_encoded_fmt_stream_map' + params['url_encoded_fmt_stream_map']);
			var test = params['url_encoded_fmt_stream_map'].split(",url=");
			
			for (var index = 0; index < test.length; index++)
			{
				
				//alert(test[index].indexOf(',itag') + '<--test[index] ' + test[index]);
				var need_help = test[index].indexOf(',itag');
				if(need_help>0)
				{
					var helper = test[index].substr(0,need_help);
					test[index] = helper;
				}
				
				var videoinfo = test[index].split("&itag=");
				videoinfo[0] = videoinfo[0].replace("url=","");


				if (videoinfo[1] == '37')
				{
					url = videoinfo[0];
					mode = "HD 1080p";
					break;				
				}
				if (videoinfo[1] == '22')
				{
					url = videoinfo[0];
					mode = "HD 720p";
					break;
				}
				if (videoinfo[1] == '18')
				{
					url = videoinfo[0];
					break;
				}
				if (videoinfo[1] == '5')
				{
					url = videoinfo[0];
					break;
				}					
			}

		}

		var test1 = document.cookie;
		document.cookie = "nitrogen14=true";
		var test2 = window.document.cookie;

		url = url.replace(/\%3A/g,":");
		url = url.replace(/\%2F/g,"/");
		url = url.replace(/\%3F/g,"?");
		url = url.replace(/\%3D/g,"=");
		url = url.replace(/\%252C/g,",");
		url = url.replace(/\%26/g,"&");
		url = url.replace(/\%253/g,":");
		
		return url;
}

function parseXml_MegaVideo(resp)
    {
        var i;
        var j;
        var k1;
        var k2;
        var un;
        var s;
        var doc=resp.responseText;
        alert(doc);
       
       j=doc.indexOf(' k1=');
       i=doc.indexOf('"',j)+1;
       j=doc.indexOf('"',i);
       k1=doc.substr(i,j-i);
       
        j=doc.indexOf(' k2=');
       i=doc.indexOf('"',j)+1;
       j=doc.indexOf('"',i);
       k2=doc.substr(i,j-i);
       
        j=doc.indexOf(' un=');
       i=doc.indexOf('"',j)+1;
       j=doc.indexOf('"',i);
       un=doc.substr(i,j-i);
       
        j=doc.indexOf(' s=');
       i=doc.indexOf('"',j)+1;
       j=doc.indexOf('"',i);
       s=doc.substr(i,j-i);
       
       alert(k1);
       alert(k2);
       alert(un);
       var d=Megavideo_decrypt(un,k1,k2);
        var url="http://www"+s+".megavideo.com/files/"+d+"/";
        //alert(url);
        //Player.setVideoURL(url);
        //Player.playVideo();
		return url;
}

function hexdec (hex_string) {
    hex_string = (hex_string+'').replace(/[^a-f0-9]/gi, '');
    return parseInt(hex_string, 16);
}

function dechex (number)
    {
        if (number < 0) 
            {
                number = 0xFFFFFFFF + number + 1;
            }
        return parseInt(number, 10).toString(16);
}

function bindec (binary_string) {
    binary_string = (binary_string+'').replace(/[^01]/gi, '');
    return parseInt(binary_string, 2);
}

function Megavideo_decrypt(str_hex, key1, key2)
{
  var i;
  var temp;
  var s;
  str_bin = new Array;
  for (i=0; i < 128; i++) 
	str_bin[i]=Math.floor(hexdec(str_hex[Math.floor(i/4)])  /Math.pow(2,(3-(i%4))))%2

	var key = new Array();
	for (i=0; i < 384; i++) 
		{
			key1 = (key1 * 11 + 77213) % 81371;
			key2 = (key2 * 17 + 92717) % 192811;
			key[i] = (key1 + key2) % 128;
		}
	
	
	for (i = 256; i >= 0; i--)
		{
			temp = str_bin[key[i]];
			str_bin[key[i]] = str_bin[i%128];
			str_bin[i%128] = temp;
		}
		
		for (i = 0; i < 128; i++)
				str_bin[i] =str_bin[i] ^ key[i+256] & 1;
		
		str_hex = "";
		for(i = 0; i < 32; i++)
			{
				s="";
				s=s+str_bin[4*i]+str_bin[4*i+1]+str_bin[4*i+2]+str_bin[4*i+3]
				str_hex += dechex(bindec(s));
			}
		return str_hex;
}