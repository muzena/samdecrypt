﻿var NFLXReset = {
}

NFLXReset.reset = function() {
	alert("Netflix UnBind Start...");
	WMGlobal.ExternalWidgetInterface.UnBindWidget("NFLX");
	alert("Reset Complete!");
}
