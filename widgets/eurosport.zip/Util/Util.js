var Util = {}

Util.timeDifference = function (heuredeb,heurefin){
   hd=heuredeb.split(":");
   hf=heurefin.split(":");
   hd[0]=parseInt(hd[0],10);
   hd[1]=parseInt(hd[1],10);
   hd[2]=parseInt(hd[2],10);
   hf[0]=parseInt(hf[0],10);
   hf[1]=parseInt(hf[1],10);
   hf[2]=parseInt(hf[2],10);
   if(hf[2]<hd[2]) {
            hf[1]=hf[1]-1;
            hf[2]=hf[2]+60;
   }
   if(hf[1]<hd[1]) {
            hf[0]=hf[0]-1;
            hf[1]=hf[1]+60;
   }
   if(hf[0]<hd[0]) {
            hf[0]=hf[0]+24;
   }
   return (((hf[0]-hd[0]) * 3600) +  ((hf[1]-hd[1]) * 60) + (hf[2]-hd[2]));
}

Util.count = function (source){
    var sourceEval = eval(source);
    var nbProperty = 0;
    for (prop in sourceEval) {
    //    if (typeof(sourceEval[prop])  == "object") {
            nbProperty++;
     //   }
        
    }
    return nbProperty;
}

Util.dayOf = function(date) {
    var tabJour = new Array("Dimanche","Lundi","Mardi","Mercredi", "Jeudi", "Vendredi","Samedi");
    var tabMois = new Array("janvier","f&eacute;vrier","mars","avril","mai","juin","juillet","ao&ucirc;t","septembre","octobre","novembre","d&eacute;cembre");
    var split = date.split("/");
    var givenDate = new Date(split[2], split[1] - 1, split[0]);
    var jour = givenDate.getDay();
    var numero = givenDate.getDate();
    numero  = (numero<10)?"0"+numero:numero;
    mois = givenDate.getMonth();
    var annee = givenDate.getFullYear();
    
    return tabJour[jour] + " " + numero + " " + tabMois[mois] + " " + annee;
}

Util.timeFormat = function (heuredeb,heurefin){
         if(Define.debugFlag) alert("Util.timeFormat ()");
        var time = Util.timeDifference(heuredeb,heurefin);
        var heure = parseInt(time/3600);
        var min = (time - (heure*3600))/60;
        if (heure > 0) {
            return heure + "h" + min ;
        } else {
            return  min + " min"   ;
        }
        
}


Util.DateUSFormat = function (dateUs,heure){
         if(Define.debugFlag) alert("Util.DateUSFormat ()");
         if(dateUs == undefined) {
                    return;
         }
        reg = new RegExp("[-:]+", "g");
        var info = dateUs.split(reg);
        var time = heure.split(reg);
        var heure = time[0];
        var min = time[1];
        var month = parseInt(info[1],10);
        var DateFr = info[2] + " " + MOIS[month - 1] + " " + info[0];
        return DateFr + " à " + heure + "h" + min ;
}

Util.stringFormat_category = function (chaine,taille,caractere){
        //alert("Util.stringFormat ()");
        if(chaine == null) return;
        if(chaine.length < taille)
        {
            var output = chaine;
        }
        else
        {
            var new_chaine = chaine.substr(0,taille);
            var index_blanc = new_chaine.lastIndexOf(" ");
            var output =  new_chaine.substr(0,index_blanc);
        }
        
 
       if(chaine.length == output.length) {
                return output;
        } else {
                return output + caractere;
        }
        
}

Util.stringFormat = function (chaine,taille,caractere){
        //alert("Util.stringFormat ()");
        var output = chaine.substr(0,taille);
        if(chaine.length == output.length) {
                return output;
        } else {
                return output + caractere;
        }
        
}

Util.wrapInTable = function (pContents) {
    var retValue = "";
    
	retValue += "<table cellpadding=0px' cellspacing='0px' border='0' >";
	retValue += "<tr>";
	retValue += "<td><div id='contentTitle'>" + pContents["EMI_SERIE"] + "</div></td>";
	retValue += "</tr>";
    retValue += "<tr><td height='5'>&nbsp;</td></tr>";
    retValue += "<tr>";
	retValue += "<td>";
    	retValue += "<table cellpadding=0px' cellspacing='0px' border='0' >";
        retValue += "<tr valign='top'>";
        if(pContents["MEDIA"] != null) {
           retValue += "<td><img src='" + pContents["MEDIA"]  + "'></td>";
           retValue += "<td width='8'></td>";
        }
        retValue += "<td valign='top'>";
                	retValue += "<div id='contentSousTitle'>" +  pContents["CON_TITRE_COURT"] + "</div>";
                    var reg = new RegExp("[ ]+", "g");
                    var dateDiff = pContents["EMI_HEURE_DEB_COMPLET"].split(reg);
                    var dateDiff = Util.DateUSFormat(dateDiff[0],dateDiff[1]);
                    if (typeof(dateDiff) != "undefined")  {     
                            retValue += "<div id='contentDiffusion'>Diffusion : " + dateDiff + "</div>";
                    }
                	retValue += "<div id='contentDuration'>Durée :  " + Util.timeFormat(pContents["EMI_HEURE_DEB"],pContents["EMI_HEURE_FIN"]) + "</div>";
                	retValue += "<div id='contentGenerique'>" + Util.stringFormat( pContents["EMI_GENERIQUE"],214,'...') + "</div>";
        retValue += "</td>";
        retValue += "</tr>";
        retValue += "</table>";
	retValue += "</td>";
	retValue += "</tr>";
    retValue += "<tr><td height='5'>&nbsp;</td></tr>";
    if(pContents["EMI_RESUME"].length  > 0) {
        retValue += "<tr>";
        retValue += "<td><div id='contentLabelResume'>Résumé";
        retValue += "</div id='contentResume'>" + pContents["EMI_RESUME"] + "</td>";
        retValue += "</tr>";
    }
	retValue += "</table>";
    retValue += "<a id='UIContentsDescriptionAnchor' style='text-decoration:none' href=javascript:>&nbsp;</a>";
	
	alert("Util.wrapInTable() returns [" + retValue + "]");
	return retValue;
}



















