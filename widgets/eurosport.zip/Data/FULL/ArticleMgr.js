var ArticleMgr = function (paramObject) {
    var id = paramObject.id;
    var article = null;
    var XHRTool = new XHRToolKit(paramObject.url, function (result) {
        onReceiveData(result);
    });
    
    var classement = new Array();
    var calendrier = new Array();
    var resultats = new Array();
    var type = Define.typeArticle;
    
    this.getResultats = function() {
        return resultats;
    }
    
    this.getCalendrier = function() {
        return calendrier;
    }
    
    this.getClassement = function() {
        return classement;
    }           
            
    this.getId = function() {
        return id;
    }
    
    this.getArticle = function () {
        alert("ArticleMgr.getArticle()");
        return article;
    }
    
    this.getType = function() {
        return type;
    }
    
    this.activate = function() {
        alert("ArticleMgr.activate() | ID = " + id);
        // get category datas via ajax
        DataMgr.setHttpAjaxRequestBusy(true);
        XHRTool.sendXHRRequest();
    }
        
    var onReceiveData = function(bSuccess) {
        alert("ArticleMgr.onReceiveData(" + bSuccess + ") | ID = " + id);
     if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
        if (bSuccess) {
            var response = XHRTool.getResponseText();
            if (response) {
                eval('article = ' + response + ';');

                if (article["resultats"]) {
                    resultats = article["resultats"];
                    type = Define.typeResultats;
                }
                
                if (article["calendrier"]) {
                    calendrier = article["calendrier"];
                    type = Define.typeCalendrier;
                }
                
                if (article["classement"]) {
                    classement = article["classement"];
                    type = Define.typeClassement;                    
                }
            }
        }
        
        DataMgr.setHttpAjaxRequestBusy(false);
        UIArticle.init();
  } catch(ex) {
              UIError.showTechnicalError();
      }
        alert("ArticleMgr.onReceiveData() End");
    }
}