var CategoryMgr = function (paramObject) {
    var id = paramObject.id;						// category ID
    var title = paramObject.title;					// category title
    var parentRubrique = paramObject.parentRubrique;					// rubrique parente si existe
    var XHRTool = new XHRToolKit(paramObject.url, function (result) {
        onReceiveData(result);
    });
    var url = XHRTool.getUrl();
    var highlightFirst = null;
    
    var arrArticles = new Array();				// Article structure array
    
    this.getId = function() {
        return id;
    }    
    
    this.getTitle = function() {
        return title;
    }
    
    this.hasParentRubrique = function() {
        return parentRubrique;
    }
    
    this.getArticles = function () {
        return arrArticles;		
    }
    
    this.getUrl = function() {
        return url;
    }    
    
    this.getArticleId = function(idx) {
        alert("CategoryMgr.getArticleId(" + idx + ")");
        if (arrArticles[idx]) {
            return arrArticles[idx]["id"];
        }
        return false;
    }
    
    this.setArticles = function(articles) {
        arrArticles = articles;
    }
    
     this.getNbArticles = function() {
        return arrArticles.length;
     }
   
   this.hasArticles = function() {
        if (arrArticles.length) {
            return true;
        }
        return false;
   }

    
    this.activate = function(highlightFirstElement) {
        // get category datas via ajax
        highlightFirst = highlightFirstElement;
        //arrArticles = new Array();
        DataMgr.setHttpAjaxRequestBusy(true);
        XHRTool.sendXHRRequest();
    }
    
    var onReceiveData = function(bSuccess) {
        alert("CategoryMgr.onReceiveData(" + bSuccess + ") | ID = " + id);
     if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
        if (bSuccess) {
            var response = XHRTool.getResponseText();
            if (response) {
                eval('var responseJson = ' + response + ';');

                if (responseJson["articles"]) {
                    arrArticles = responseJson["articles"];
                }
            }
        }

        UICategory.init();
        if(highlightFirst == true) {
            UICategory.highlightTitle(0);
            /*if(id == Define.rubFootball) {
                UICategory.highlightButton(0);            
            }*/
        }
        DataMgr.setHttpAjaxRequestBusy(false);
       } catch(ex) {
              UIError.showTechnicalError();
      }
        alert("CategoryMgr.onReceiveData() End");
    }
}