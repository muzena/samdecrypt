var XHRToolKit = function (pURL, pSendResultFunc) {
    var URL = pURL;
    var sendResultFunc = pSendResultFunc;
    var XHRObj = null;
    
    this.sendXHRRequest = function() {
        if (XHRObj)
            XHRObj.destroy();
        XHRObj = new XMLHttpRequest();      
        var pluginAPI = new Common.API.Plugin(); 
        
        if (XHRObj) {
            XHRObj.onreadystatechange = function () {
            
                 if (XHRObj.readyState == 3) {
                        // Stop WatchDog function
                        pluginAPI.setOffWatchDog();
                } else if(XHRObj.readyState == 4) {
                        // Execute WatchDog function
                        pluginAPI.setOnWatchDog();
                }
    
                if (XHRObj.readyState == 4) {
                    receiveXHRResponse();
                }
            };
            XHRObj.open("GET", URL, true);
            XHRObj.send(null);
        }
        else 	{
            alert("XHR Object is NULL");
        }
    }

    var receiveXHRResponse = function(){
    
        if (XHRObj.status == 200) {
            alert("Good XHR response");
            sendResultFunc(true);
        }
        else {
            alert("Bad XHR response.");
            sendResultFunc(false);
        }
    }
    
    this.getResponseXML = function () {
        return XHRObj.responseXML;
    }
    
    this.getResponseText = function() {
        return XHRObj.responseText;
    }
	
	this.getXHRObj = function () {
		return XHRObj;
	}
    
    this.abortXHRObj = function () {
        if (XHRObj) {
            XHRObj.abort();
        }
    }
    
    this.getUrl = function() {
        return URL;
    }
}