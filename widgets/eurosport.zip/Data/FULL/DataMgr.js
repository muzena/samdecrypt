var DataMgr = {
    arrCategoryList : new Array(),			// Category list
    fullArticle : null,
    filnews : null,
    startSubCatFoot : null,
    startSubLigue1 : null,
    startSubLigue2 : null,
    currentLigue : 0,
    httpAjaxRequestBusy : false,
    XHRTool : new XHRToolKit(Define.serverAddress + Define.homeAjaxUrl, function (result) {
        DataMgr.onReceiveData(result);
    })
}

DataMgr.activate = function () {
    alert("DataMgr.activate()");    
    // get article via ajax
    
     this.XHRTool.sendXHRRequest();
}

DataMgr.onReceiveData = function (bSuccess) {
    alert("DataMgr.onReceiveData("+bSuccess+")");
    if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
    if (bSuccess) {
        var response = this.XHRTool.getResponseText();
        if (response) {
            eval('var responseJson = ' + response + ';');
        
            // set categories

            var i = 0;
            var rub_array = IDMgr.getInfo("rubriques");
            for (j in rub_array)  {                
                this.arrCategoryList[i] = new CategoryMgr({
                        id: rub_array[j]["id"],
                        title: rub_array[j]["name"],
                        parentRubrique : null,
                        url: Define.serverAddress +  ((rub_array[j]["id"] != "1" && rub_array[j]["id"] != "2") ? Define.categoryAjaxUrl + rub_array[j]["id"] : Define.homeAjaxUrl)
                });
                i++;
            }
            
            //init des sous catégories du foot
            this.startSubCatFoot = i;
            var subCatFoot_array = IDMgr.getInfo("subCategoriesFootball");
            for (j in subCatFoot_array)  {
                var key = subCatFoot_array[j]["id"].split("-");
                this.arrCategoryList[i] = new CategoryMgr({
                        id: subCatFoot_array[j]["id"],
                        title: subCatFoot_array[j]["name"],
                        parentRubrique : IDMgr.getInfo("rubFootball"),
                        url: Define.serverAddress + Define.subCategoryAjaxUrl + key[0]+ "&by="+key[1]
                });
                i++;
            }            
            
            //init des sous catégories de la ligue 1
            this.startSubLigue1 = i;
            var subLigue1_array = IDMgr.getInfo("subCategoriesLigue1");
            for (j in subLigue1_array)  {
                var key = subLigue1_array[j]["id"].split("-");
                
                switch(key[2]) {
                    case "res" :
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue1_array[j]["id"],
                                title: subLigue1_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue1"),
                                url: Define.serverAddress + Define.resultatsAjaxUrl + key[0]
                        });
                        break;
                        
                    case "cal" :
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue1_array[j]["id"],
                                title: subLigue1_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue1"),
                                url: Define.serverAddress + Define.calendrierAjaxUrl + key[0]
                        });       
                        break;                        
                        
                    case "class" :
                        var key = subLigue1_array[j]["id"].split("-");
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue1_array[j]["id"],
                                title: subLigue1_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue1"),
                                url: Define.serverAddress + Define.classementAjaxUrl + key[3]
                        });
                        break;                       
                        
                    case "actu" :
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue1_array[j]["id"],
                                title: subLigue1_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue1"),
                                url: Define.serverAddress + Define.subCategoryAjaxUrl + key[0]+ "&by="+key[1]
                        });       
                        break;
                }
                i++;
            }    
            
            //init des sous catégories de la ligue 2
            this.startSubLigue2 = i;
            var subLigue2_array = IDMgr.getInfo("subCategoriesLigue2");
            for (j in subLigue2_array)  {
                var key = subLigue2_array[j]["id"].split("-");
                
                switch(key[2]) {
                    case "res" :
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue2_array[j]["id"],
                                title: subLigue2_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue2"),
                                url: Define.serverAddress + Define.resultatsAjaxUrl + key[0]
                        });
                        break;
                        
                    case "cal" :
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue2_array[j]["id"],
                                title: subLigue2_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue2"),
                                url: Define.serverAddress + Define.calendrierAjaxUrl + key[0]
                        });       
                        break;                        
                        
                    case "class" :
                        var key = subLigue2_array[j]["id"].split("-");
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue2_array[j]["id"],
                                title: subLigue2_array[j]["name"],
                                parentRubrique : IDMgr.getInfo("rubLigue2"),
                                url: Define.serverAddress + Define.classementAjaxUrl + key[3]
                        });
                        break;                       
                        
                    case "actu" :
                        this.arrCategoryList[i] = new CategoryMgr({
                                id: subLigue2_array[j]["id"],
                                title: subLigue2_array[j]["name"],
                                 parentRubrique : IDMgr.getInfo("rubLigue2"),
                                url: Define.serverAddress + Define.subCategoryAjaxUrl + key[0]+ "&by="+key[1]
                        });       
                        break;
                }
                i++;
            }
                                    
            if(Define.debugFlag) alert(this.arrCategoryList.length + " categories created.");
        }
    }
    
    UIHome.init();
      } catch(ex) {
              UIError.showTechnicalError();
      }
    alert("DataMgr.onReceiveData() End");
}

DataMgr.hasCategories = function() {
    if (this.arrCategoryList.length) {
        return true;
    }
    return false;
}

DataMgr.isHttpAjaxRequestBusy = function() {
    return this.httpAjaxRequestBusy;
}

DataMgr.setHttpAjaxRequestBusy = function(state) {
    this.httpAjaxRequestBusy = state;
}

DataMgr.getNbCategory = function() {
    return this.arrCategoryList.length;
}

DataMgr.getCategory = function() {
    if (this.arrCategoryList[NewsController.currentCategory]) {
        return this.arrCategoryList[NewsController.currentCategory];
    }
    return false;
}

DataMgr.testCategory = function(idCategory) {
    if (this.arrCategoryList[idCategory]) {
        return this.arrCategoryList[idCategory];
    }
    return false;
}

DataMgr.setArticle = function(id) {
    if(Define.debugFlag) alert("DataMgr.setArticle(" + id + ")");
    this.fullArticle = new ArticleMgr({
        id: id,
        url: Define.serverAddress + Define.articleAjaxUrl + id
    });
}

DataMgr.setResultats = function(id, pUrl) {
    if(Define.debugFlag) alert("DataMgr.setArticle()");
    this.fullArticle = new ArticleMgr({
        id: id,
        url: pUrl
    });
}

DataMgr.getArticle = function() {
    if(Define.debugFlag) alert("DataMgr.getArticle()");
    return this.fullArticle;
}

DataMgr.getStartSubFoot = function() {
    if(Define.debugFlag) alert("DataMgr.getStartSubFoot()");
    return this.startSubCatFoot;
}

DataMgr.getStartSubLigue1 = function() {
    if(Define.debugFlag) alert("DataMgr.getStartSubLigue1()");
    return this.startSubLigue1;
}

DataMgr.getStartSubLigue2 = function() {
    if(Define.debugFlag) alert("DataMgr.getStartSubLigue2()");
    return this.startSubLigue2;
}

DataMgr.setCurrentLigue = function(ligue) {
    this.currentLigue = ligue;
}

DataMgr.getCurrentLigue = function() {
    return this.currentLigue;
}

DataMgr.setFilnews = function() {
    if(Define.debugFlag) alert("DataMgr.setFilnews()");
    if (!this.filnews) {
        this.filnews = new FilnewsMgr({
            url: Define.serverAddress + Define.filnewsAjaxUrl
        });
    }
}

DataMgr.getFilnews = function() {
    if(Define.debugFlag) alert("DataMgr.getFilnews()");
    return this.filnews;
}

DataMgr.hasChildrenCategories = function(idCategory) {
    if(Define.debugFlag) alert("DataMgr.hasChildrenCategories()");
    for (var i = 0; i < this.arrCategoryList.length; i++) {
        if(this.arrCategoryList[i].hasParentRubrique() != null && this.arrCategoryList[i].hasParentRubrique() == idCategory) {
            return true;
        }
    }
    return false;
}

DataMgr.getChildrenCategories = function(idCategory) {
    if(Define.debugFlag) alert("DataMgr.getChildrenCategories()");
    var j = 0;
    var arrChildrenCategoryList = new Array();
    
    for (var i = 0; i < this.arrCategoryList.length; i++) {
        if(this.arrCategoryList[i].hasParentRubrique() != null && this.arrCategoryList[i].hasParentRubrique() == idCategory) {
            arrChildrenCategoryList[j] = this.arrCategoryList[i];
            j++;            
        }
    }
    return arrChildrenCategoryList;
}

DataMgr.retrieveIndexCategoryById = function(idCategory) {
    if(Define.debugFlag) alert("DataMgr.retrieveIndexCategoryById()");
    for (var i = 0; i < this.arrCategoryList.length; i++) {
        if(this.arrCategoryList[i].getId() == idCategory) {
            return i;
        }
    }
    return -1;
}