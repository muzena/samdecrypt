var IDMgr = {
       reg : null,
       regName : null,
       XHRTool : null,
       infoSport : null,
}

IDMgr.create = function () {
    alert("IDMgr.create()");
    this.reg = new RegExp("[:]+", "g");
    this.regName = new RegExp("[#]+", "g");
    this.XHRTool = new XHRToolKit(Define.serverAddress + Define.idFluxAjaxUrl, function (result) {
        IDMgr.onReceiveData(result);
    })
    this.XHRTool.sendXHRRequest();
    alert("IDMgr.create() End");
}

IDMgr.refresh = function () {
    alert("IDMgr.refresh()");
    this.reg = new RegExp("[:]+", "g");
    this.regName = new RegExp("[#]+", "g");
    this.XHRTool = new XHRToolKit(Define.serverAddress + Define.idFluxAjaxUrl, function (result) {
        IDMgr.onReceiveData(result);
    })
    this.XHRTool.sendXHRRequest();
    alert("IDMgr.refresh() End");
}



IDMgr.getInfo = function(index) {
    return this.infoSport[index];
}



IDMgr.getData = function (source) {
    alert("source =>>" + source);
    infoSource = source.split(this.regName);
    var variable = eval(infoSource[0]);
    var index = infoSource[1];
    var variableTemp = variable[index];
    return variableTemp;
}

IDMgr.onReceiveData = function (bSuccess) {
    alert("IDMgr.onReceiveData("+bSuccess+")");
    
    if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
            if (bSuccess) {
                var response = this.XHRTool.getResponseText();
                if (response) {
                    eval( response );
                }
                NewsController.create(); 
            }
        } catch(ex) {
              UIError.showTechnicalError();
      }
    alert("IDMgr.onReceiveData() End");
}

















