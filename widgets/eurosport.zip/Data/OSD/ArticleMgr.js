var ArticleMgr = function (paramObject) {
    var id = paramObject.id;
    var article = null;
    var XHRTool = new XHRToolKit(paramObject.url, function (result) {
        onReceiveData(result);
    });
    
    var classement = new Array();
    var calendrier = new Array();
    var resultats = new Array();
	var comments = new Array();
	
    var type = Define.typeArticle;
    
    this.getResultats = function() {
        return resultats;
    }
    
    this.getCalendrier = function() {
        return calendrier;
    }
    
    this.getClassement = function() {
        return classement;
    }
	
	this.getComments = function() {
        return comments;
    }
            
    this.getId = function() {
        return id;
    }
    
    this.getArticle = function () {
        if(Define.debugFlag) alert("ArticleMgr.getArticle()");
        return article;
    }
    
    this.getType = function() {
        return type;
    }
    
    this.activate = function() {
        alert("ArticleMgr.activate() | ID = " + id);
        // get category datas via ajax
        XHRTool.sendXHRRequest();
    }
        
    var onReceiveData = function(bSuccess) {
        alert("ArticleMgr.onReceiveData(" + bSuccess + ") | ID = " + id);
        if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
        if (bSuccess) {
            var response = XHRTool.getResponseText();
            if (response) {
                eval('article = ' + response + ';');

				if (article["lives"]) {
                    comments = article["lives"];
                    type = Define.typeComments;
                }

                if (article["resultats"]) {
                    resultats = article["resultats"];
                    type = Define.typeResultats;					
                }
                
                if (article["calendrier"]) {
                    calendrier = article["calendrier"];
                    type = Define.typeCalendrier;
                }
                
                if (article["classement"]) {
                    classement = article["classement"];
                    type = Define.typeClassement;                    
                }				
            }
        }
        
        UIArticle.init();     
     } catch(ex) {
              UIError.showTechnicalError();
      }
        alert("ArticleMgr.onReceiveData() End");
    }
}