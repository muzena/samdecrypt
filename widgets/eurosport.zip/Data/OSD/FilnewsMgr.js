var FilnewsMgr = function (paramObject) {
    var XHRTool = new XHRToolKit(paramObject.url, function (result) {
        onReceiveData(result);
    });
    
    var arrNews = new Array();				// Article structure array
    var indexCurr = 0;
    
    this.getNews = function () {
        return arrNews;		
    }  
    
    this.getIndexCurr = function () {
        return indexCurr;		
    }
    
    this.nextIndexCurr = function () {
        if(indexCurr + 1 < arrNews.length) {
            indexCurr++;		
        } else {
            indexCurr = 0;
        }
    }    
    
    this.setNews = function(news) {
        arrNews = news;
    }
    
     this.getNbNews = function() {
        return arrNews.length;
     }
    
   this.hasNews = function() {
        if (arrNews.length) {
            return true;
        }
        return false;
   }

    
    this.activate = function() {
        // get filnews datas via ajax
        XHRTool.sendXHRRequest();
    }
    
    var onReceiveData = function(bSuccess) {
        alert("FilnewsMgr.onReceiveData(" + bSuccess + ")");
        if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
        if (bSuccess) {
            var response = XHRTool.getResponseText();
            if (response) {
                eval("var responseJson = " + response + ";");
                if (responseJson["news"]) {
                    arrNews = responseJson["news"];
                }
            }
        }
        
        // load news for visible UI
        if (UIFilnews.isVisible()) {
            UIFilnews.init();
        }
        if (UITicker.isVisible()) {
            UITicker.init();
        }
    } catch(ex) {
              UIError.showTechnicalError();
      }      
        alert("FilnewsMgr.onReceiveData() End");
    }
}