var CategoryMgr = function (paramObject) {
    var id = paramObject.id;						// category ID
    var title = paramObject.title;					// category title
    var parentRubrique = paramObject.parentRubrique;					// rubrique parente si existe
    var XHRTool = new XHRToolKit(paramObject.url, function (result) {
        onReceiveData(result);
    });
    var url = XHRTool.getUrl();
    
    var arrArticles = new Array();				// Article structure array
    var articleUne = null;
    
    this.getId = function() {
        return id;
    }    
    
    this.getTitle = function() {
        return title;
    }
    
    this.hasParentRubrique = function() {
        return parentRubrique;
    }
    
    this.getArticles = function () {
        return arrArticles;		
    }   
    
    this.getUrl = function() {
        return url;
    }
    
    this.getArticleId = function(idx) {
        alert("CategoryMgr.getArticleId(" + idx + ")");
        if (idx < 0 && articleUne) {
            // return une id
            return this.getArticleUneId();
        } else if (arrArticles[idx]) {
            return arrArticles[idx]["id"];
        }
        return false;
    }
    
    this.setArticles = function(articles) {
        arrArticles = articles;
    }
    
     this.getNbArticles = function() {
        return arrArticles.length;
     }
    
    this.setArticleUne = function(article) {
        articleUne = article;
    }
    
   this.getArticleUne = function() {
        return articleUne;
   }
   
   this.getArticleUneId = function() {
        if (articleUne) {
            return articleUne["id"];
        }
        return false;
   }
   
   this.hasArticles = function() {
        if (arrArticles.length) {
            return true;
        }
        return false;
   }

    
    this.activate = function() {
        // get category datas via ajax
        articleUne = null;
        arrArticles = new Array();
        XHRTool.sendXHRRequest();
    }
    
    var onReceiveData = function(bSuccess) {
        alert("CategoryMgr.onReceiveData(" + bSuccess + ") | ID = " + id);
        if (bSuccess == false) {
        UIError.showNetworklError();
        return;
    }
    try {
        if (bSuccess) {
            var response = XHRTool.getResponseText();
            if (response) {
                eval('var responseJson = ' + response + ';');
                if (responseJson["une"]) {
                    articleUne = responseJson["une"];
                }
                if (responseJson["articles"]) {
                    arrArticles = responseJson["articles"];
                }
            }
        }
        
        UICategory.init();
    } catch(ex) {
              UIError.showTechnicalError();
      }
        alert("CategoryMgr.onReceiveData() End");
    }
}