var NewsController = {
    currentState : null,		// current UI state
    currentCategory : 0,  // current selected category idx
    currentArticle : 0, // current selected news idx    
    arrPathSub : new Array(), //permet de retracer le chemin en remontant les sous catégories
    
    // UI state
    UIHOME : 1,
    UICATEGORY : 2,
    UISUBCATEGORY : 21,
    UIARTICLE : 3,
    UIFILNEWS : 4,
    UITICKER : 5,    
    
    REFRESH_TIME : 100000,    //5min
    
    // Process
    HOME_UP : 100,
    HOME_DOWN : 101,
    HOME_ENTER : 102,
    HOME_RETURN : 103,
    HOME_RIGHT : 104,
    CATEGORY_UP : 200,
    CATEGORY_DOWN : 201,  
    CATEGORY_LEFT : 202,
    CATEGORY_RIGHT : 203,
    CATEGORY_ENTER : 204,
    CATEGORY_RETURN : 205,
    ARTICLE_UP : 300,
    ARTICLE_DOWN : 301,
    ARTICLE_LEFT : 302,
    ARTICLE_RIGHT : 303,
    ARTICLE_RETURN : 304,
    FILNEWS_UP : 400,
    FILNEWS_DOWN : 401,
    FILNEWS_RETURN : 402,
    FILNEWS_BLUE : 403,
    FILNEWS_LEFT : 404,
    TICKER_RETURN : 500
}

NewsController.create = function() {
    UIError.create();
    DataMgr.activate();        
    KeyHandler.create();
    UIHome.create();
    UICategory.create();
    UIArticle.create();
    UIFilnews.create();
    UITicker.create();
    UIHome.show();    
    //setTimeout("NewsController.refresh()", NewsController.REFRESH_TIME);        
}

NewsController.request = function (REQUEST) {
    alert("NewsController.request("+REQUEST+")");
    switch (REQUEST) {
        
        // HOME
        case this.HOME_UP:
                UIHome.moveUp();
                break;
                
        case this.HOME_DOWN:
                UIHome.moveDown();
                break;
                
         case this.HOME_RIGHT:    
         case this.HOME_ENTER:
                switch (UIHome.titleIdx) {
                        case 0:
                            this.homeToFilnews();
                            break;
                            
                       case 1:
                            this.homeUne();
                            break;
                            
                       default:
                            this.homeToCategory();
                            break;      
                    }
                    break;
                    
            case this.HOME_RETURN:
                //widgetAPI.sendReturnEvent();
                break;
                    
            // CATEGORY
            case this.CATEGORY_UP:
                    UICategory.moveUp();
                    break;
                    
            case this.CATEGORY_DOWN:
                    UICategory.moveDown();                    
                    break;            
            
            case this.CATEGORY_RIGHT:
            case this.CATEGORY_ENTER:
                    //si on est dans une catégorie sans enfant (afficher un article ou la une)
                    if(this.currentState == this.UICATEGORY) {                        
                        this.categoryArticle();
                    }
                    
                    //si on est dans une catégorie qui possède une catégorie parente
                    if(this.currentState == this.UISUBCATEGORY) {                        
                        switch (UICategory.buttonIdx) {
                           case 0:
                                this.categoryIntermediaireUne();
                                break;
                                
                           default:
                                this.categoryIntermediaireEnter();
                                break;      
                        }
                    }
                    break;
             
            case this.CATEGORY_LEFT :
            case this.CATEGORY_RETURN:
                    this.anyCategoryBack();
                    break;
        
            // ARTICLE
            case this.ARTICLE_UP:
                    UIArticle.moveUp();
                    break;
                    
            case this.ARTICLE_DOWN:
                    UIArticle.moveDown();
                    break;

            case this.ARTICLE_LEFT:
            case this.ARTICLE_RETURN:
                    this.articleBack();
                    break;
                    
            // FILNEWS
            case this.FILNEWS_UP:
                UIFilnews.moveUp();
                break;
                
            case this.FILNEWS_DOWN:
                UIFilnews.moveDown();
                break;
                
            case this.FILNEWS_LEFT:   
            case this.FILNEWS_RETURN:
                UIFilnews.hide();
                UIHome.show();
                break;
                
            case this.FILNEWS_BLUE:
                UIFilnews.hide();
                UITicker.show();
                
                DataMgr.setFilnews();
                DataMgr.getFilnews().activate();
                break;
                
           // TICKER
           case this.TICKER_RETURN:
                UITicker.hide();
                UIFilnews.show();
                
                DataMgr.setFilnews();
                DataMgr.getFilnews().activate();
                break;
                    
        default:
            break;
    }
}

// ****************************************** /

NewsController.homeToFilnews = function() {
    // Filnews
    UIHome.hide();
    UIFilnews.show();
    
    DataMgr.setFilnews();
    DataMgr.getFilnews().activate();          
}

NewsController.homeUne = function() {
    // Une
    if (DataMgr.articleUne) {
        UIHome.hideFooter();
        UICategory.hideFooter();
        UIHome.blurTitle(UIHome.titleIdx);
        UIHome.selectTitle(UIHome.titleIdx);
        UIArticle.show();        
        this.currentArticle = DataMgr.articleUne["id"];
        
        var type = DataMgr.articleUne["type"];
        
        if(type == "commentLive") {
                DataMgr.setContent("event-"+this.currentArticle, Define.serverAddress + Define.commentsAjaxUrl + this.currentArticle);	
                alert(Define.serverAddress + Define.commentsAjaxUrl + this.currentArticle);
		} else {				    
			DataMgr.setArticle(this.currentArticle);
		}
		
		DataMgr.getArticle().activate();		
        this.currentState = this.UIHOME;
    }
}

NewsController.homeToCategory = function() {
    // category                            
    this.currentCategory = UIHome.getHighlightedCategory();
    var currentCategoryMgr = DataMgr.getCategory();                                                                                  
    if (currentCategoryMgr != false) {                                
        UIHome.hide();                                                                
        UICategory.show();
        UICategory.buttonIdx = 0;
        currentCategoryMgr.activate();                                  
        //test si il y a des sous catégories
        if(!DataMgr.hasChildrenCategories(currentCategoryMgr.getId())) {
            this.currentState = this.UICATEGORY; //état pour les catégories qui n'ont pas de sous catégories
        } else {
            this.currentState = this.UISUBCATEGORY; //état pour les catégories sont des sous catégories
            NewsController.setLigueFromCategory(currentCategoryMgr);            
        }                                       
    }
}

NewsController.setLigueFromCategory = function(categoryMgr) {
    if(categoryMgr.getId() == IDMgr.getInfo("ligue1Res") || categoryMgr.getId() == IDMgr.getInfo("ligue1Cal") 
        || categoryMgr.getId() == IDMgr.getInfo("ligue1Class") || categoryMgr.getId() == IDMgr.getInfo("ligue1Actu")
        || categoryMgr.getId() == IDMgr.getInfo("rubLigue1")) {
        DataMgr.setCurrentLigue(1);
        return;
    }
    
    if(categoryMgr.getId() == IDMgr.getInfo("ligue2Res") || categoryMgr.getId() == IDMgr.getInfo("ligue2Cal") 
        || categoryMgr.getId() == IDMgr.getInfo("ligue2Class") || categoryMgr.getId() == IDMgr.getInfo("ligue2Actu")
        || categoryMgr.getId() == IDMgr.getInfo("rubLigue2")) {
        DataMgr.setCurrentLigue(2);
        return;
    }    
    DataMgr.setCurrentLigue(0);
}

NewsController.articleBack = function() {
    UIArticle.hide();
    switch (this.currentState) {
        case this.UIHOME :
            UIHome.unselectTitle(UIHome.titleIdx);
            UIHome.highlightTitle(UIHome.titleIdx);
            break;
            
        case this.UICATEGORY :
            UICategory.unselectTitle(UICategory.titleIdx);
            UICategory.highlightTitle(UICategory.titleIdx);
            break;                                             
            
        case this.UISUBCATEGORY :
            UICategory.unselectButton(UICategory.buttonIdx);
            UICategory.highlightButton(UICategory.buttonIdx);
            break;                                                                     
    }
}

NewsController.categoryArticle = function() {
    // Une
    if(UICategory.titleIdx == 0) {
            this.currentArticle = DataMgr.getCategory().getArticleUneId();
    } else { // article
            this.currentArticle = DataMgr.getCategory().getArticleId(UICategory.startIdx + UICategory.titleIdx - 1);
    }
    
    if (this.currentArticle) {                                    
        UIHome.hideFooter();
        UICategory.hideFooter();
        UICategory.blurTitle(UICategory.titleIdx);
        UICategory.selectTitle(UICategory.titleIdx);
        UIArticle.show();
        
        DataMgr.setArticle(this.currentArticle);
        DataMgr.getArticle().activate();
        this.currentState = this.UICATEGORY;
    }
}

NewsController.anyCategoryBack = function() {
    var currentCategoryMgr = DataMgr.getCategory();
    //si la catégorie n'est pas une sous catégorie, revenir à la home
    if(currentCategoryMgr.hasParentRubrique() == null) {
        UICategory.hide();
        UIHome.show();
        DataMgr.setCurrentLigue(0);
    } else { //sinon revenir à la catégorie parent        
        var buttonIdx = this.arrPathSub.pop();
        this.currentCategory = DataMgr.retrieveIndexCategoryById(currentCategoryMgr.hasParentRubrique());
        var parentCategoryMgr = DataMgr.getCategory();                        
        NewsController.setLigueFromCategory(parentCategoryMgr);
        parentCategoryMgr.activate();                      
        UICategory.show();                   
        UICategory.setHighlightedButton(buttonIdx-1);
        this.currentState = this.UISUBCATEGORY;                                                                            
    }
}

NewsController.categoryIntermediaireUne = function() {
    // Une
    this.currentArticle = DataMgr.getCategory().getArticleUneId();
    if (this.currentArticle) {
        UIHome.hideFooter();
        UICategory.hideFooter();
        UICategory.blurButton(UICategory.buttonIdx);
        UICategory.selectButton(UICategory.buttonIdx);
        UIArticle.show();
        
        DataMgr.setArticle(this.currentArticle);
        DataMgr.getArticle().activate();
        this.currentState = this.UISUBCATEGORY;
    }
}

NewsController.activateSubButton = function(categoryMgr) {
    this.arrPathSub.pop();
    UICategory.blurButton(UICategory.buttonIdx);
    UICategory.selectButton(UICategory.buttonIdx);
    DataMgr.setContent(categoryMgr.getId(), categoryMgr.getUrl());
    DataMgr.getArticle().activate();
    UIArticle.show();
}

NewsController.categoryIntermediaireEnter = function() {
    
    this.arrPathSub.push(UICategory.buttonIdx);  
    var testCatMgr = DataMgr.testCategory(UICategory.getHighlightedButton());
    
    if(testCatMgr != false) {
        
        switch(testCatMgr.getId()) {
        
            case IDMgr.getInfo("ligue1Res") :
            case IDMgr.getInfo("ligue1Cal") :
            case IDMgr.getInfo("ligue1Class") :
            case IDMgr.getInfo("ligue2Res") :
            case IDMgr.getInfo("ligue2Cal") :
            case IDMgr.getInfo("ligue2Class") :
                this.activateSubButton(testCatMgr);
                break;
                
            default :
                // permet de descendre dans les hiérarchies de catégories        
                this.currentCategory = UICategory.getHighlightedButton();
                var currentCategoryMgr = DataMgr.getCategory();
                
                UICategory.show();
                currentCategoryMgr.activate();
                if(!DataMgr.hasChildrenCategories(currentCategoryMgr.getId())) {
                    this.currentState = this.UICATEGORY;
                } else {
                    UICategory.setHighlightedButton(-1);                  
                    this.currentState = this.UISUBCATEGORY;
                }
                
        }
        NewsController.setLigueFromCategory(testCatMgr);
    }
}
