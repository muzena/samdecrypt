var Main = {
    startCategoryID : 0,
    XHRObj:null
}

var widgetAPI = new Common.API.Widget();
var pluginAPI = new Common.API.Plugin();
var NNaviPlugin = null; //leetd
var PL_NNAVI_STATE_BANNER_NONE = 0;
var PL_NNAVI_STATE_BANNER_VOL = 1;
var PL_NNAVI_STATE_BANNER_VOL_CH = 2;

Main.onLoad = function() {
    if(Define.debugFlag) alert("Main.onLoad()");
    window.onShow = onShowEventHandler;
    IDMgr.create();
    widgetAPI.sendReadyEvent();
    
    NNaviPlugin = document.getElementById("pluginObjectNNavi");       //leetd  
	NNaviPlugin.SetBannerState(PL_NNAVI_STATE_BANNER_VOL);   //leetd
 }

Main.onUnload = function() {
   // NNaviPlugin.SetBannerState(PL_NNAVI_STATE_BANNER_NONE);	//leetd
}