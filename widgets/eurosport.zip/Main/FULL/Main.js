var Main = {
    startCategoryID : 0,
    XHRObj:null
}

var widgetAPI = new Common.API.Widget();
var pluginAPI = new Common.API.Plugin();
var NNaviPlugin = null; //leetd
var TVMWPlugin = null;
var oldSource = null;
var OSDState = false;
var PL_NNAVI_STATE_BANNER_NONE = 0;
var PL_NNAVI_STATE_BANNER_VOL = 1;
var PL_NNAVI_STATE_BANNER_VOL_CH = 2;

Main.PreLoad = function() {

    var lang_id;
    var _THIS_ =  this;

    var url_query = decodeURI(window.location.search);

  if (!url_query) {
        url_query = "?country=FR&language=13&modelid=LNXXB650&server=development&keyword=TF1&from=side";
  }
    
    alert(url_query);
    
    var matched = url_query.match(/([\w_]+)=([\w\d]+)/gi);

    for (var x = 0; x < matched.length; x++)
    {
        arr = matched[x].match(/([\w_]+)=([\w\d]+)/i);
        if (arr[1] == "language") {
            lang_id = parseInt(arr[2]);
        }
        else if (arr[1] == "modelid") {
            this.area_code = arr[2];
        }
        else if (arr[1] == "from") {
            if (arr[2] == "side") {
                OSDState = true;
            }else {
                OSDState = false;
            }
            
        }

    }
    
  

    if(OSDState == true) {
            document.location.href="indexOSD.html"; 
    } else {
            Main.changeSource();
            Main.onLoad();         
    }
 }

Main.onLoad = function() {
    alert("Main.onLoad()");
    window.onShow = onShowEventHandler;
    IDMgr.create();
    widgetAPI.sendReadyEvent();
        
    NNaviPlugin = document.getElementById("pluginObjectNNavi");       //leetd  
	NNaviPlugin.SetBannerState(PL_NNAVI_STATE_BANNER_VOL);   //leetd
 }

Main.onUnload = function() {
 //   NNaviPlugin.SetBannerState(PL_NNAVI_STATE_BANNER_NONE);	//leetd
       if(OSDState != true) {
                Main.restoreSource();
      }
}

Main.changeSource = function () {
    // Changing Source
    TVMWPlugin = document.getElementById("pluginObjectTVMW");
    alert("TVMWPlugin : "+ TVMWPlugin);
    oldSource = TVMWPlugin.GetSource();
    alert("oldSource : "+ oldSource);
    TVMWPlugin.SetMediaSource();
}

Main.restoreSource = function () {
    // Recover Source
    if( TVMWPlugin != null) {
        TVMWPlugin.SetSource(oldSource);
        alert("EndSource : "+ TVMWPlugin.GetSource());
        oldSource = null; 
    }
}