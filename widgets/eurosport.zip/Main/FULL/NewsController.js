var NewsController = {
    currentState : null,		// current UI state
    currentCategory : 0,  // current selected category idx
    currentArticle : 0, // current selected news idx    
    arrPathSub : new Array(), //permet de retracer le chemin en remontant les sous catégories
    
    // UI state
    UIHOME : 1,
    UICATEGORY : 2,
    UISUBCATEGORY : 21,
    UIARTICLE : 3,
    UIFILNEWS : 4,
    
    REFRESH_TIME : 100000,    //5min
    
    // Process
    HOME_UP : 100,
    HOME_DOWN : 101,
    HOME_ENTER : 102,
    HOME_RETURN : 103,
    HOME_RIGHT : 104,
    CATEGORY_UP : 200,
    CATEGORY_DOWN : 201,  
    CATEGORY_LEFT : 202,
    CATEGORY_RIGHT : 203,
    CATEGORY_ENTER : 204,
    CATEGORY_RETURN : 205,
    ARTICLE_UP : 300,
    ARTICLE_DOWN : 301,
    ARTICLE_LEFT : 302,
    ARTICLE_RIGHT : 303,
    ARTICLE_RETURN : 304,
    FILNEWS_UP : 400,
    FILNEWS_DOWN : 401,
    FILNEWS_RETURN : 402,
    FILNEWS_BLUE : 403,
    FILNEWS_LEFT : 404,
}

NewsController.create = function() {
    UIError.create();
    DataMgr.activate();        
    KeyHandler.create();
    UIHome.create();
    UICategory.create();
    UIArticle.create();
    UIFilnews.create();
    UIHome.show();    
    this.currentState = this.UIHOME;
    //setTimeout("NewsController.refresh()", NewsController.REFRESH_TIME);           
}

NewsController.request = function (REQUEST) {
    alert("NewsController.request("+REQUEST+")");
    switch (REQUEST) {
        
        // HOME
        case this.HOME_UP:
             if(DataMgr.isHttpAjaxRequestBusy() ==false) // pour eviter les conflits AJAX
            {
                UIHome.moveUp();
             } 
                break;
                
        case this.HOME_DOWN:
            if(DataMgr.isHttpAjaxRequestBusy() ==false)  // pour eviter les conflits AJAX
            {
                UIHome.moveDown();
             }  
                break;
                
         case this.HOME_RIGHT:    
         case this.HOME_ENTER:
                if(UIHome.titleIdx == 0) {
                   this.homeToFilnewsFocus();
                } else {
                    this.homeToCategory(true);
                }
                break;
                    
            case this.HOME_RETURN:
                //widgetAPI.sendReturnEvent();
                break;
                    
            // CATEGORY
            case this.CATEGORY_UP:                
                    if(this.currentState != this.UISUBCATEGORY) {
                        UICategory.moveUp();
                    } else {
                        UICategory.calculatePosition(REQUEST);
                    }
                    break;
                    
            case this.CATEGORY_DOWN:
                    if(this.currentState != this.UISUBCATEGORY) {                    
                        UICategory.moveDown();                    
                    } else {
                        UICategory.calculatePosition(REQUEST);
                    }
                    break;            
            
            case this.CATEGORY_RIGHT:            
                    if(this.currentState == this.UICATEGORY) {                        
                        this.categoryArticle();
                    } else {
                        UICategory.calculatePosition(REQUEST);
                    }
                    break;
                    
            case this.CATEGORY_ENTER:
                    //si on est dans une catégorie sans enfant (afficher un article ou la une)
                    if(this.currentState == this.UICATEGORY) {                        
                        this.categoryArticle();
                    } else { //si on est dans une catégorie qui possède une catégorie parente                                       
                        this.categoryIntermediaireEnter();
                    }
                    break;
             
            case this.CATEGORY_LEFT :
                    if(this.currentState == this.UICATEGORY){                        
                        this.anyCategoryBack();
                    } 
                    else if (this.currentState == this.UISUBCATEGORY) {
                        this.anyCategoryBack();
                    }
                    else {
                        UICategory.calculatePosition(REQUEST);
                    }         
                    break;
            
            case this.CATEGORY_RETURN:                
                    this.anyCategoryBack();
                    break;
        
            // ARTICLE
            case this.ARTICLE_UP:
                    UIArticle.moveUp();
                    break;
                    
            case this.ARTICLE_DOWN:
                    UIArticle.moveDown();
                    break;

            case this.ARTICLE_LEFT:
            case this.ARTICLE_RETURN:
                    this.articleBack();
                    break;
                    
            // FILNEWS
            case this.FILNEWS_UP:
                UIFilnews.moveUp();
                break;
                
            case this.FILNEWS_DOWN:
                UIFilnews.moveDown();
                break;
                
            case this.FILNEWS_LEFT:   
            case this.FILNEWS_RETURN:                
                this.filnewsBack();
                this.currentState = this.UIHOME;
                break;               
                    
        default:
            break;
    }
}

// ****************************************** /
NewsController.homeToFilnewsFocus = function() {
       UIHome.blurTitle(UIHome.titleIdx);
       UIHome.selectTitle(UIHome.titleIdx);
       UIFilnews.realShow();
      this.currentState = this.UIFILNEWS;
}

NewsController.homeToFilnews = function() {
    // Filnews
   
       if(DataMgr.isHttpAjaxRequestBusy() ==false){
            UIHome.blurTitle(UIHome.titleIdx);
            UIHome.selectTitle(UIHome.titleIdx);
            UIFilnews.show();
            DataMgr.setFilnews();    
            DataMgr.getFilnews().activate();    
            this.currentState = this.UIFILNEWS;
    } 
   
}

NewsController.filnewsBack = function() {
    // Filnews    
    KeyHandler.focusToHome();
    UIHome.blurTitle(UIHome.titleIdx);
    UIHome.unselectTitle(UIHome.titleIdx);
    UIHome.highlightTitle(UIHome.titleIdx);    
}

NewsController.homeToCategory = function(highlightFirstElement) {
    // category                  
    this.currentCategory = UIHome.getHighlightedCategory();
    var currentCategoryMgr = DataMgr.getCategory();                                                                                  
    if (currentCategoryMgr != false && DataMgr.isHttpAjaxRequestBusy() == false) {                                
        //test si il y a des sous catégories
        if(!DataMgr.hasChildrenCategories(currentCategoryMgr.getId())) {
            UIHome.blurTitle(UIHome.titleIdx);
            UIHome.selectTitle(UIHome.titleIdx);
            UICategory.showArticleListe();
            KeyHandler.focusToCategory();            
            currentCategoryMgr.activate(highlightFirstElement);            
            this.currentState = this.UICATEGORY; //état pour les catégories qui n'ont pas de sous catégories
        } else { //pour foot par exemple
            UIHome.blurTitle(UIHome.titleIdx);
            UIHome.selectTitle(UIHome.titleIdx);            
            UICategory.buttonIdx = highlightFirstElement ? 0 : -1;
            UICategory.hideArticleListe();
            UICategory.showSubListe();
            KeyHandler.focusToCategory();
            currentCategoryMgr.activate(highlightFirstElement);			
            this.currentState = this.UISUBCATEGORY; //état pour les catégories sont des sous catégories        
            NewsController.setLigueFromCategory(currentCategoryMgr);            
        }                                       
    }
}

NewsController.setLigueFromCategory = function(categoryMgr) {
    if(categoryMgr.getId() == IDMgr.getInfo("ligue1Res") || categoryMgr.getId() == IDMgr.getInfo("ligue1Cal") 
        || categoryMgr.getId() == IDMgr.getInfo("ligue1Class") || categoryMgr.getId() == IDMgr.getInfo("ligue1Actu")
        || categoryMgr.getId() == IDMgr.getInfo("rubLigue1")) {
        DataMgr.setCurrentLigue(1);
        return;
    }
    
    if(categoryMgr.getId() == IDMgr.getInfo("ligue2Res") || categoryMgr.getId() == IDMgr.getInfo("ligue2Cal") 
        || categoryMgr.getId() == IDMgr.getInfo("ligue2Class") || categoryMgr.getId() == IDMgr.getInfo("ligue2Actu")
        || categoryMgr.getId() == IDMgr.getInfo("rubLigue2")) {
        DataMgr.setCurrentLigue(2);
        return;
    }    
    DataMgr.setCurrentLigue(0);
            
}

NewsController.articleBack = function() {
    UIArticle.hide();
    switch (this.currentState) {
        case this.UIHOME :
            UIHome.unselectTitle(UIHome.titleIdx);
            UIHome.highlightTitle(UIHome.titleIdx);
            break;
            
        case this.UICATEGORY :
            UICategory.unselectTitle(UICategory.titleIdx);
            UICategory.highlightTitle(UICategory.titleIdx);
            break;                                             
            
        case this.UISUBCATEGORY :  
            UICategory.updateFooter4fleches();
            UICategory.showSubListe();
            UICategory.hideArticleListe();
            UICategory.unselectButton(UICategory.buttonIdx);
            UICategory.highlightButton(UICategory.buttonIdx);
            break;                                                                     
    }
}

NewsController.categoryArticle = function() {

    this.currentArticle = DataMgr.getCategory().getArticleId(UICategory.startIdx + UICategory.titleIdx);    
    if (this.currentArticle && DataMgr.isHttpAjaxRequestBusy() == false) {                                                    
        UIArticle.show();                
        DataMgr.setArticle(this.currentArticle);
        DataMgr.getArticle().activate();
        this.currentState = this.UICATEGORY;
    }
}

NewsController.anyCategoryBack = function() {
    var currentCategoryMgr = DataMgr.getCategory();
    //si la catégorie n'est pas une sous catégorie, revenir à la home
    if(currentCategoryMgr.hasParentRubrique() == null) {
        UICategory.blurTitle(UICategory.titleIdx);
        UICategory.blurButton(UICategory.buttonIdx);
        UIHome.unselectTitle(UIHome.titleIdx);        
        UIHome.highlightTitle(UIHome.titleIdx);
        UIHome.show();
        DataMgr.setCurrentLigue(0);
    } else { //sinon revenir à la catégorie parent                
        if(DataMgr.isHttpAjaxRequestBusy() == false) {
            var buttonIdx = this.arrPathSub.pop();
            this.currentCategory = DataMgr.retrieveIndexCategoryById(currentCategoryMgr.hasParentRubrique());
            var parentCategoryMgr = DataMgr.getCategory();                        
            NewsController.setLigueFromCategory(parentCategoryMgr);        
            parentCategoryMgr.activate(false);                    
            UICategory.setHighlightedButton(buttonIdx-1);
            this.currentState = this.UISUBCATEGORY;         
			UICategory.clean();
        }
    }
}

NewsController.activateSubButton = function(categoryMgr) {
    if(DataMgr.isHttpAjaxRequestBusy() == false) {       
        this.arrPathSub.pop();
        UICategory.hideSubListe();
        DataMgr.setResultats(categoryMgr.getId(), categoryMgr.getUrl());   
        DataMgr.getArticle().activate();
        UIArticle.show();
    }
}

NewsController.categoryIntermediaireEnter = function() {
    
    this.arrPathSub.push(UICategory.buttonIdx);  
    var testCatMgr = DataMgr.testCategory(UICategory.getHighlightedButton());
    
    if(testCatMgr != false && DataMgr.isHttpAjaxRequestBusy() == false) {
        
        switch(testCatMgr.getId()) {
        
            case IDMgr.getInfo("ligue1Res") :
            case IDMgr.getInfo("ligue1Cal") :
            case IDMgr.getInfo("ligue1Class") :
            case IDMgr.getInfo("ligue2Res") :
            case IDMgr.getInfo("ligue2Cal") :
            case IDMgr.getInfo("ligue2Class") :                
                this.activateSubButton(testCatMgr);
                break;
                
            default :
                // permet de descendre dans les hiérarchies de catégories        
                this.currentCategory = UICategory.getHighlightedButton();
                var currentCategoryMgr = DataMgr.getCategory();                    				
                currentCategoryMgr.activate(true);                
                UICategory.showSubListe();
                if(!DataMgr.hasChildrenCategories(currentCategoryMgr.getId())) {
                    this.currentState = this.UICATEGORY;
                } else {
                    UICategory.setHighlightedButton(-1);
                    this.currentState = this.UISUBCATEGORY;
                }                
				UICategory.clean();
        }
        NewsController.setLigueFromCategory(testCatMgr);
    }
}