var KeyHandler = {
    tvKey : null,
    listAnchor : null,
    categoryAnchor : null,
    articleAnchor : null,
    filnewsAnchor : null,
    keyBlockerAnchor : null
}



KeyHandler.create = function() {
    alert("KeyHandler.create()");
    this.listAnchor = document.getElementById("List_Anchor");
    this.categoryAnchor = document.getElementById("Category_Anchor");
    this.articleAnchor = document.getElementById("Article_Anchor");
    this.filnewsAnchor = document.getElementById("Filnews_Anchor");
    this.keyBlockerAnchor = document.getElementById("KeyBlocker_Anchor");
    this.tvKey = new Common.API.TVKeyValue();
    KeyHandler.registerKeylist();
}


onShowEventHandler = function()
{
   KeyHandler.registerKeylist();
}


KeyHandler.registerKeylist = function() {
    pluginAPI.registKey(this.tvKey.KEY_MENU);
    pluginAPI.registKey(this.tvKey.KEY_MUTE);
    pluginAPI.registKey(this.tvKey.KEY_VOL_UP);
    pluginAPI.registKey(this.tvKey.KEY_VOL_DOWN);
}




KeyHandler.focusToHome = function() {
    this.listAnchor.focus();
}

KeyHandler.focusToCategory = function() {
    this.categoryAnchor.focus();
}

KeyHandler.focusToArticle = function() {
    this.articleAnchor.focus();
}

KeyHandler.focusToFilnews = function() {
    this.filnewsAnchor.focus();
}

KeyHandler.focusToKeyBlocker = function() {
    this.keyBlockerAnchor.focus();
}

KeyHandler.keyBlocker = function() {
    var keyBlockerKeyCode = event.keyCode;
    alert("KeyHandler.keyBlocker()");
}

KeyHandler.homeKeyDown = function() {
    var keyCode = event.keyCode;
    
    alert("KeyHandler.homeKeyDown = " + keyCode);
    
    switch(keyCode) {
        case this.tvKey.KEY_LEFT:
			NewsController.request(NewsController.HOME_LEFT);
            break;
        case this.tvKey.KEY_RIGHT:
			NewsController.request(NewsController.HOME_RIGHT);
            break;
        case this.tvKey.KEY_UP:
            NewsController.request(NewsController.HOME_UP);
            break;
        case this.tvKey.KEY_DOWN:
            NewsController.request(NewsController.HOME_DOWN);
            break;
        case this.tvKey.KEY_ENTER: 
            NewsController.request(NewsController.HOME_ENTER);
            break;
        case this.tvKey.KEY_RETURN:
            NewsController.request(NewsController.HOME_RETURN);
            break;
        case this.tvKey.KEY_RIGHT :
            NewsController.request(NewsController.HOME_RIGHT);
            break;
    }
}


KeyHandler.categoryKeyDown = function() {
    var keyCode = event.keyCode;
    
    alert("KeyHandler.categoryKeyDown = " + keyCode);
    
    switch(keyCode) {
        case this.tvKey.KEY_UP:
            NewsController.request(NewsController.CATEGORY_UP);
            break;
        case this.tvKey.KEY_DOWN:
            NewsController.request(NewsController.CATEGORY_DOWN);
            break;
        case this.tvKey.KEY_LEFT:
            NewsController.request(NewsController.CATEGORY_LEFT);
            break;
        case this.tvKey.KEY_RIGHT:
            NewsController.request(NewsController.CATEGORY_RIGHT);
            break;
        case this.tvKey.KEY_ENTER:
            NewsController.request(NewsController.CATEGORY_ENTER);
            break;
        case this.tvKey.KEY_RETURN:
            widgetAPI.blockNavigation(event);
            NewsController.request(NewsController.CATEGORY_RETURN);
            break;
    }
}



KeyHandler.articleKeyDown = function() {
    var keyCode = event.keyCode;
    
    alert("KeyHandler.articleKeyDown = " + keyCode);
    
    switch(keyCode) {
        case this.tvKey.KEY_UP:
            NewsController.request(NewsController.ARTICLE_UP);
            break;
        case this.tvKey.KEY_DOWN:
            NewsController.request(NewsController.ARTICLE_DOWN);
            break;
        case this.tvKey.KEY_LEFT:
            NewsController.request(NewsController.ARTICLE_LEFT);
            break;
        case this.tvKey.KEY_RIGHT:
            NewsController.request(NewsController.ARTICLE_RIGHT);
            break;
        case this.tvKey.KEY_RETURN:
            widgetAPI.blockNavigation(event);
            NewsController.request(NewsController.ARTICLE_RETURN);
            break;
    }
}

KeyHandler.filnewsKeyDown = function() {
    var keyCode = event.keyCode;
    
    alert("KeyHandler.filnewsKeyDown = " + keyCode);
    
    switch(keyCode) {
        case this.tvKey.KEY_UP:
            NewsController.request(NewsController.FILNEWS_UP);
            break;
        case this.tvKey.KEY_DOWN:
            NewsController.request(NewsController.FILNEWS_DOWN);
            break;
        case this.tvKey.KEY_RETURN:
            widgetAPI.blockNavigation(event);
            NewsController.request(NewsController.FILNEWS_RETURN);
            break;
        case this.tvKey.KEY_BLUE:
            NewsController.request(NewsController.FILNEWS_BLUE);
            break;
        case this.tvKey.KEY_LEFT:
            NewsController.request(NewsController.FILNEWS_LEFT);
            break;           
    }
}