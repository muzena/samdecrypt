// init
var Define = {
    imageNotFound: "Resource/image/x.gif",  // url to default image
   /* rubriques: {
        "1" :"&Agrave la Une",
        "22" :"Football",
        "39":"Auto-Moto",
        "44":"Rugby",
        "57":"Tennis",
        "82":"J.O. d'hiver Vancouver",
		"2" :"Articles les plus lus"
    },  // categories list
    
    subCategoriesFootball : {
        "199-rub" :"Les transferts",
        "31427-event":"Ligue 1",
        "31430-event":"Ligue 2",
        "31483-event":"Champions League",
        "277-team":"Equipe<br/>de France"
    },  // sub categories list for football
    
    subCategoriesLigue1 : {
        "31427-event-res" : "Résultats<br/>Ligue 1",
        "31427-event-cal" : "Calendrier<br/>Ligue 1",
        "31427-event-class-60411" : "Classement<br/>Ligue 1", 
        "31427-event-actu" : "Actu<br/>Ligue 1" 
    },
        
    subCategoriesLigue2 : {
        "31430-event-res" : "Résultats<br/>Ligue 2",
        "31430-event-cal" : "Calendrier<br/>Ligue 2",
        "31430-event-class-60412" : "Classement<br/>Ligue 2", 
        "31430-event-actu" : "Actu<br/>Ligue 2"
    },
    */
    
    //id pour les switch
   // rubFootball : "22",
    //rubLigue1 : "31427-event",
    //rubLigue2 : "31430-event",
  //  ligue1Res : "31427-event-res",
//    ligue1Cal : "31427-event-cal",
   // ligue1Class : "31427-event-class-60411",
   // ligue1Actu : "31427-event-actu",
   // ligue2Res : "31430-event-res",
 //   ligue2Cal : "31430-event-cal",
   // ligue2Class : "31430-event-class-60412",
  //  ligue2Actu : "31430-event-actu",        
    
    homeDefaultSelected: 1, /* (0 = filnews / 1 -> x = category) */
    
    //serverAddress : "http://212.23.180.100", 
    serverAddress : "http://nettv.tf1.fr",

    idFluxAjaxUrl: "/php/SPORT/id_flux.php",
    homeAjaxUrl: "/php/SPORT/sportListeArticles.php?type=homefull",
    categoryAjaxUrl: "/php/SPORT/sportListeArticles.php?type=categoryfull&count=20&id=",
    commentLiveAjaxUrl: "/php/SPORT/sportDetailComment.php?id=",
    articleAjaxUrl: "/php/SPORT/sportDetailArticle.php?id=",   // url to ajax call for retrieving article datas
    filnewsAjaxUrl : "/php/SPORT/sportListeFilnews.php?count=20",  // url to ajax call for retrieving filnews datas
    subCategoryAjaxUrl : "/php/SPORT/sportListeArticles.php?type=categoryfull&count=20&id=",
    resultatsAjaxUrl : "/php/SPORT/sportResultat.php?event=",
    calendrierAjaxUrl : "/php/SPORT/sportCalendrier.php?event=",
    classementAjaxUrl : "/php/SPORT/sportClassement.php?standing=",     
    referentialAjaxUrl : "/php/SPORT/sportReferential.php",
  
    typeArticle : 0,
    typeResultats : 1,
    typeCalendrier : 2,
    typeClassement : 3, 
 
    articleScrollPixels : 25, // number of pixels to scroll for each move in full article    
    debugFlag : false
}