var UIFilnews = {
    listArea : null,			// UIList Div
    arrTitles : new Array(),	// Array of Title Divs
    titleIdx : null,				// title index being highlighted
    startIdx : null,             // start index of categories list
    visible : false
}

UIFilnews.create = function() {
    if(Define.debugFlag) alert("UIFilnews.create()");
    this.listArea = document.getElementById("UIFilnews");
    this.titleIdx = 5;
    this.startIdx = 0;
    
    // init buttons
    var parentDivList = document.getElementById("UIFilnewsArticles");
    if (parentDivList) {
        var childListCount = parentDivList.childNodes.length;
        for (var i=0; i<childListCount; i++) {
            this.arrTitles[i] = document.getElementById('UIFilnews_btn' + i);
        }
    }
    if(Define.debugFlag) alert("UIFilnews.create() : " + this.arrTitles.length + " buttons created");
}

UIFilnews.displayNews = function(arrData) {
    if(Define.debugFlag) alert("UIFilnews.displayNews()");
    if (arrData) {
        for (var i=0; i<arrData.length; i++) {
            if (this.arrTitles[i] && arrData[i]) {
                var innerHTML = "<div class='UIFilnewsArticleInfo'><span class='UIFilnewsArticleTime'>";
                if (arrData[i].date_time) {
                    innerHTML += arrData[i].date_time;
                }
                innerHTML += "</span><span class='UIFilnewsArticleTitle'>";
                if (arrData[i].event_name) {
                    innerHTML += arrData[i].event_name;
                }
                
                /*
                if(this.titleIdx + this.startIdx == this.startIdx + i) {
                    innerHTML += "</span></div><div class='UIFilnewsArticleText_focus'>";
                } else {
                    innerHTML += "</span></div><div class='UIFilnewsArticleText'>";
                }*/
                   
                innerHTML += "</span></div><div class='UIFilnewsArticleText'>";   
                if (arrData[i].name) {
                    innerHTML += arrData[i].name;
                }
                innerHTML += "</div>";
                widgetAPI.putInnerHTML(this.arrTitles[i], innerHTML);
            }
        }
    }
}

UIFilnews.init = function() {
    if(Define.debugFlag) alert("UIFilnews.init()");
    var mgr = DataMgr.getFilnews();

    // articles list
    this.blurTitle(this.titleIdx);
    if (mgr.hasNews()) {
        this.titleIdx = 5;
        this.startIdx = 0;
        this.displayNews(mgr.getNews().slice(this.startIdx, this.arrTitles.length));
        document.getElementById("UIFilnewsScrollBar").style.display = "block";
        this.updateScrollbar(mgr);
        this.highlightTitle(this.titleIdx);
    } else {
        widgetAPI.putInnerHTML(document.getElementById("UIFilnews_btn0"), "<br />Aucune info disponible");
        document.getElementById("UIFilnewsScrollBar").style.display = "none";
    }
}

UIFilnews.updateScrollbar = function() {
    var total = DataMgr.getFilnews().getNbNews();
    var cssTop = Math.floor((this.startIdx + this.titleIdx - 5) * (310-45) / (total-1-5));
    if (cssTop == 0) {cssTop = -5;}
    if(Define.debugFlag) alert("UIFilnews.updateScrollbar -> " + cssTop + "px");
    document.getElementById("UIFilnewsScrollBead").style.top = cssTop + "px";
}

UIFilnews.show = function() {
    if(Define.debugFlag) alert("UIFilnews.show()");
    this.showLoading();
    this.listArea.style.display = "block";
    KeyHandler.focusToFilnews();
    this.visible = true;
}

UIFilnews.showLoading = function() {
    if(Define.debugFlag) alert("UIFilnews.showLoading()");
    this.blurTitle(this.titleIdx);
    widgetAPI.putInnerHTML(document.getElementById("UIFilnews_btn0"), "<br />Chargement en cours...");
    for (var i = 1; i < this.arrTitles.length; i++) {
        widgetAPI.putInnerHTML(document.getElementById("UIFilnews_btn" + i), "");
    }
}

UIFilnews.hide = function() {
    if(Define.debugFlag) alert("UIFilnews.hide()");
    this.listArea.style.display = "none";
    KeyHandler.focusToKeyBlocker();		// block remote controller key event
    this.visible = false;
}

UIFilnews.highlightTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIFilnews.highlightTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_focus";
    }
}

UIFilnews.blurTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIFilnews.blurTitle("+pIndex+")");
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UIFilnews.moveUp = function() {
    if(Define.debugFlag) alert("UIFilnews.moveUp()");
    // already on top, do nothing    
    if (UIFilnews.onTop()) {
        return false;
    }    
    
    if (this.titleIdx < 1 + 5 && this.startIdx > 0) {
        // top of list but we just need to update list (without moving selected div)
        this.startIdx--;
        this.displayNews(DataMgr.getFilnews().getNews().slice(this.startIdx, this.startIdx + this.arrTitles.length));        
    } else {
        // move selected div up
        this.blurTitle(this.titleIdx);
        this.titleIdx--;
        this.highlightTitle(this.titleIdx);
     }
     
     // update scrollbar (only if article is selected)
    this.updateScrollbar();
    return true;
}

UIFilnews.moveDown = function() {
    if(Define.debugFlag) alert("UIFilnews.moveDown()");
    // already on bottom, do nothing    
    if (UIFilnews.onBottom()) {
        return false;
    }
    
    if (this.titleIdx == this.arrTitles.length - 1) {
        // bottom of list but we just need to update list
        this.startIdx++;
        this.displayNews(DataMgr.getFilnews().getNews().slice(this.startIdx, this.startIdx + this.arrTitles.length));        
    } else {
        // move selected div down
        this.blurTitle(this.titleIdx);
        this.titleIdx++;
        this.highlightTitle(this.titleIdx);        
    }    
    
    // update scrollbar
    this.updateScrollbar();   
    return true;
}

UIFilnews.isVisible = function() {
    if(Define.debugFlag) alert("UIFilnews.isVisible()");
    return this.visible;
}

UIFilnews.onBottom = function() {
    if ((this.titleIdx + this.startIdx) >= DataMgr.getFilnews().getNbNews() - 1) {
        return true;
    }
}

UIFilnews.onTop = function() {
    if (this.titleIdx < 1 + 5 && this.startIdx < 1) {
        return true;
    }    
}