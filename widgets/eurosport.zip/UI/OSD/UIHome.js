var UIHome = {
    listArea : null,			// UIList Div
    arrTitles : new Array(),	// Array of Title Divs
    titleIdx : null				// title index being highlighted
}

UIHome.create = function() {
    if(Define.debugFlag) alert("UIHome.create()");
    this.listArea = document.getElementById("UIHome");
    this.titleIdx = Define.homeDefaultSelected;
        
    this.arrTitles[0] = document.getElementById("UIHome_btn0");
    this.arrTitles[1] = document.getElementById("UIHome_btn1");        
}

UIHome.init = function() {
    if(Define.debugFlag) alert("UIHome.init()");
    this.displayUne();
    this.displayCategories();
	
	//NewsController.homeUne();
	//NewsController.articleBack();
}

UIHome.displayCategories = function() {
    // display categories
    if(Define.debugFlag) alert("UIHome.displayCategories()");
    if (DataMgr.hasCategories()) {
        var buttonsHtml = '';
        for (var i=0; i < DataMgr.arrCategoryList.length; i++)  {
            if(!DataMgr.arrCategoryList[i].hasParentRubrique()) {                
                buttonsHtml += '<div id="UIHome_btn' + (i + 2) + '" class="UIButton"><div class="UIButtonText">' + DataMgr.arrCategoryList[i].getTitle() + '</div></div>';
            }
       }       
       widgetAPI.putInnerHTML(document.getElementById("UIHomePart1"), buttonsHtml);

       for (var i=2; i < DataMgr.arrCategoryList.length + 2; i++) {
            if(!DataMgr.arrCategoryList[i-2].hasParentRubrique()) {                
                this.arrTitles[i] = document.getElementById("UIHome_btn"+i);
            }
        }
                
        // highlight selected
        this.highlightTitle(this.titleIdx);
    } else {
        widgetAPI.putInnerHTML(document.getElementById("UIHomePart1"), "<br />Aucune catégorie disponible");
        this.highlightTitle(0);
    }
}

UIHome.displayUne = function() {
    // display une
    if(Define.debugFlag) alert("UIHome.displayUne()");
    var uneImage = document.getElementById("UIHomeUneImage");
    var uneTitle = document.getElementById("UIHomeUneTextTitle");
    var uneDesc = document.getElementById("UIHomeUneTextDesc");
    
    if (DataMgr.articleUne) {
        if (DataMgr.articleUne.image) {            
            uneImage.src = DataMgr.articleUne.image;
        } else {
            uneImage.src = Define.imageNotFound;
        }
        if (DataMgr.articleUne.event) {
            widgetAPI.putInnerHTML(uneTitle, DataMgr.articleUne.event);
        }
        if (DataMgr.articleUne.title) {
            widgetAPI.putInnerHTML(uneDesc, DataMgr.articleUne.title);
        }
    } else {
        uneImage.src = "Resource/image/x.gif";
        widgetAPI.putInnerHTML(uneTitle, "");
        widgetAPI.putInnerHTML(uneDesc, "");
    }
}

UIHome.show = function() {
    if(Define.debugFlag) alert("UIHome.show()");
    this.listArea.style.display = "block";
    KeyHandler.focusToHome();
}

UIHome.hide = function() {
    if(Define.debugFlag) alert("UIHome.hide()");
    this.listArea.style.display = "none";
    KeyHandler.focusToKeyBlocker();		// block remote controller key event
}

UIHome.hideFooter = function() {
    if(Define.debugFlag) alert("UIHome.hideFooter()");
    document.getElementById('UIHomeFooter').src = "Resource/image/footer-empty.png";
    //document.getElementById('UIHomeFooter').src = "Resource/image/Navbar_OSD_left.png";
}

UIHome.showFooter = function() {
    if(Define.debugFlag) alert("UIHome.showFooter()");
    document.getElementById('UIHomeFooter').src = "Resource/image/footer.png";
}

UIHome.getHighlightedCategory = function() {
    if (this.titleIdx > 1) {
        return this.titleIdx - 2;
    }
    return -1;
}

UIHome.setHighlightedCategory = function(idx) {
    this.blurTitle(this.titleIdx);
    this.titleIdx = idx + 2;
    this.highlightTitle(this.titleIdx);
}

UIHome.highlightTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.highlightTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_focus";
    }
}

UIHome.blurTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.blurTitle("+pIndex+")");
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UIHome.selectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.selectTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_selected");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_selected";
    }
}

UIHome.unselectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.unselectTitle("+pIndex+")");
    var reg=new RegExp("(_selected)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UIHome.moveUp = function() {
    if(Define.debugFlag) alert("UIHome.moveUp()");
    if (DataMgr.hasCategories() && this.titleIdx != 1) {
        this.blurTitle(this.titleIdx);
        if (this.titleIdx <= 0) {
            this.titleIdx = this.arrTitles.length - 1;
        } else {
            this.titleIdx--;
        }
        this.highlightTitle(this.titleIdx);
     }
    if(Define.debugFlag) alert("UIHome.articleUp() End");
}

UIHome.moveDown = function() {
    if(Define.debugFlag) alert("UIHome.moveDown()");
    if (DataMgr.hasCategories() && this.titleIdx) {
        this.blurTitle(this.titleIdx);
        if (this.titleIdx >= this.arrTitles.length - 1) {
            this.titleIdx = 0;
        } else {
            this.titleIdx++;
        }
        this.highlightTitle(this.titleIdx);
     }
     if(Define.debugFlag) alert("UIHome.articleDown() End");
}