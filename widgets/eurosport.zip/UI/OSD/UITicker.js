var UITicker = {
    listArea : null,			// UIList Div
    innerTextElt : null,
    visible : false,
    slideIdx : null
}

UITicker.create = function() {
    if(Define.debugFlag) alert("UITicker.create()");
    this.listArea = document.getElementById("UITicker");
    this.innerTextElt = document.getElementById("UITickerInnerText");
}

UITicker.clean = function() {
    if(Define.debugFlag) alert("UITicker.clean()");
    widgetAPI.putInnerHTML(this.innerTextElt, "");
}

UITicker.displayAllNews = function(arrData) {
    if(Define.debugFlag) alert("UITicker.displayNews()");
    if (this.innerTextElt && arrData) {
        this.clean();
        var innerHTML = "";
        for (var i = 0; i < arrData.length; i++) {
            /*innerHTML += "<span class='UITickerTime'>";
            if (arrData[i].date_time) {
                innerHTML += arrData[i].date_time + "</span>";
            }*/
            innerHTML += "<span class='UITickerTitle'>";
            if (arrData[i].event_name) {
                innerHTML += arrData[i].event_name;
            }
            innerHTML += "</span><span class='UITickerDesc'>";
            if (arrData[i].name) {
                innerHTML += arrData[i].name;
            }
            innerHTML += "</span>";
        }
        widgetAPI.putInnerHTML(this.innerTextElt, innerHTML);
    }
}

UITicker.displayNews = function(arrData) {
    if(Define.debugFlag) alert("UITicker.displayNews()");
    if (this.innerTextElt && arrData) {
        this.clean();
        var innerHTML = "";
        var index = DataMgr.getFilnews().getIndexCurr();
        //var descSize = Define.sizeLimitTickerFilnews - (arrData[index].time + " " + arrData[index].title).length;
        var descSize = Define.sizeLimitTickerFilnews - ("" + arrData[index].title).length;
        
        /*innerHTML += "<span class='UITickerTime'>";
        if (arrData[index].date_time) {
            innerHTML += arrData[index].date_time + "</span>";
        }*/
        innerHTML += "<span class='UITickerTitle'>";
        if (arrData[index].event_name) {
            innerHTML += arrData[index].event_name;
        }
        innerHTML += "</span><span class='UITickerDesc'>";
        if (arrData[index].name) {
            innerHTML += Util.stringFormat(arrData[index].name, descSize, "...");
        }
        innerHTML += "</span>";

        widgetAPI.putInnerHTML(this.innerTextElt, innerHTML);
    }
}

UITicker.init = function() {
    if(Define.debugFlag) alert("UITicker.init()");
    var mgr = DataMgr.getFilnews();

    if (mgr.hasNews()) {
        this.displayNews(mgr.getNews());
        
        // start sliding
        this.slideIdx = document.getElementById("UITickerText").offsetWidth;
        UITicker.slide();
    } else {
        this.clean();
        widgetAPI.putInnerHTML(this.innerTextElt, "Liste des infos non disponible");
    }
}

UITicker.show = function() {
    if(Define.debugFlag) alert("UITicker.show()");
    this.showLoading();
    this.listArea.style.display = "block";
    KeyHandler.focusToTicker();
    this.visible = true;
}

UITicker.showLoading = function() {
    if(Define.debugFlag) alert("UITicker.showLoading()");
    this.clean();
    widgetAPI.putInnerHTML(this.innerTextElt, "Chargement en cours...");
}

UITicker.hide = function() {
    if(Define.debugFlag) alert("UITicker.hide()");
    this.listArea.style.display = "none";
    KeyHandler.focusToKeyBlocker();		// block remote controller key event
    this.visible = false;
}

UITicker.slide = function() {
    if (!this.isVisible()) {
        return;
    }
    var mgr = DataMgr.getFilnews();        
    UITicker.displayNews(mgr.getNews());
    mgr.nextIndexCurr();
    setTimeout("UITicker.slide()", Define.tickerTTL);    
}

UITicker.isVisible = function() {
    return this.visible;
}