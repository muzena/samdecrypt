var UICategory = {
    listArea : null,			// UIList Div
    listArticlesArea : null,			//Div articles
    listButtonsArea : null,			//Div buttons
    arrTitles : new Array(),	// Array of Title Divs
    arrButtons : new Array(), //Array of buttons
    titleIdx : null,				// title index being highlighted
    buttonIdx : null,				// button index being highlighted
    startIdx : null,             // start index of categories list
    hasUne : false,
    uneImageElt : null,
    uneTitleElt : null,
    uneDescElt : null
}

UICategory.create = function() {
    if(Define.debugFlag) alert("UICategory.create()");
    this.listArea = document.getElementById("UICategory");
    this.listArticlesArea = document.getElementById("UICategoryArticles");
    this.listButtonsArea = document.getElementById("UICategoryButtons");
    this.uneImageElt = document.getElementById("UICategoryUneImage");
    this.uneTitleElt = document.getElementById("UICategoryUneTextTitle");
    this.uneDescElt = document.getElementById("UICategoryUneTextDesc");
    this.titleIdx = 0;
    this.buttonIdx = 0;
    this.startIdx = 0;
    
    // init une button
    this.arrTitles[0] = document.getElementById("UICategory_btn0");
    this.arrButtons[0] = document.getElementById("UICategory_btn0");
    
    // init categories button
    var parentDivList = document.getElementById("UICategoryArticles");
    if (parentDivList) {
        var childListLength = parentDivList.childNodes.length;
        for (var i=1; i<=childListLength; i++) {
            this.arrTitles[i] = document.getElementById("UICategory_btn" + i);
        }
    }
    
    parentDivList = document.getElementById("UICategoryButtons");
    if (parentDivList) {
        var childListLength = parentDivList.childNodes.length;
        for (var i=1; i<=childListLength; i++) {
            this.arrButtons[i] = document.getElementById("UICategory_butt" + i);
        }
    }    
    
    if(Define.debugFlag) alert("print 1 UICategory.create() : " + this.arrTitles.length + " articles created" + this.arrTitles);
    if(Define.debugFlag) alert("print 2 UICategory.create() : " + this.arrButtons.length + " buttons created" + this.arrButtons);
}

UICategory.clean = function() {
    if(Define.debugFlag) alert("UICategory.clean()");
    this.blurButton(this.buttonIdx);
    this.unselectButton(this.buttonIdx);    
    this.blurTitle(this.titleIdx);
    this.unselectTitle(this.titleIdx);
    this.hasUne = false;
    this.uneImageElt.src = "Resource/image/x.gif";
    widgetAPI.putInnerHTML(this.uneTitleElt, "");
    widgetAPI.putInnerHTML(this.uneDescElt, "");    
    document.getElementById("UICategory_loading").style.display = "block";
    for (var i = 1; i < this.arrTitles.length; i++) {
        widgetAPI.putInnerHTML(document.getElementById("UICategory_btn" + i), "");
    }  
}

UICategory.displayTitle = function(title) {
    if(Define.debugFlag) alert("UICategory.displayTitle()");
    var titleCategory = document.getElementById('UICategoryTitle');
    if (title && titleCategory) {
        widgetAPI.putInnerHTML(titleCategory, title);
    }
}

UICategory.displayUne = function(arrData) {
    if(Define.debugFlag) alert("UICategory.displayUne()");
    
    if (arrData) {
       /* if (arrData.event) {
            widgetAPI.putInnerHTML(this.uneTitleElt, arrData.event);
        }*/
        if (arrData.title) {
            widgetAPI.putInnerHTML(this.uneDescElt, arrData.title);
        }
        if (arrData.image) {
            this.uneImageElt.src = arrData.image;
        } else {
            this.uneImageElt.src = Define.imageNotFound;
        }
        this.hasUne = true;
    }
}

UICategory.displayArticles = function(arrData) {
    alert("UICategory.displayArticles()");
    if (arrData) {
        for (var i=0; i<arrData.length; i++) {
            if (this.arrTitles[i + 1] && arrData[i]) {
              var long = 55;                                                                              // environ deux lignes de texte             
                widgetAPI.putInnerHTML(this.arrTitles[i + 1], '<div class="UICategoryArticleText">' + Util.stringFormat_category(arrData[i].title, long, "...") + '</div>');
               // widgetAPI.putInnerHTML(this.arrTitles[i + 1], '<div class="UICategoryArticleText"><span class="UICategoryArticleTitle">' + arrData[i].title + '</span>' + Util.stringFormat_category(arrData[i].desc, long, "...") + '</div>');                
            }
        }
    }
    alert("UICategory.displayArticles() End");
}

UICategory.displayButtons = function(arrData) {
    if(Define.debugFlag) alert("UICategory.displayButtons()");
    if (arrData) {
        for (var i=0; i<this.arrButtons.length - 1; i++) {
            if (this.arrButtons[i + 1] && arrData[i]) {
                widgetAPI.putInnerHTML(this.arrButtons[i + 1], '<div class="UIButtonText">' + arrData[i].getTitle() +  '</div>');
                this.arrButtons[i + 1].style.display = "block";
            } else {
                this.arrButtons[i + 1].style.display = "none";
            }
        }
    }
    if(Define.debugFlag) alert("UICategory.displayButtons() End");
}

UICategory.init = function() {
    if(Define.debugFlag) alert("UICategory.init()");
    this.clean();
    this.titleIdx = 0;
    //this.buttonIdx = 0;
    this.startIdx = 0;
    
    var mgr = DataMgr.getCategory();
    
    // article Une
    this.displayUne(mgr.getArticleUne());
    if (this.hasUne) {
        this.titleIdx = 0;
    }

    // articles list
    if(!DataMgr.hasChildrenCategories(mgr.getId())) {
        document.getElementById("UICategory_loading").style.display = "none";
        this.listArticlesArea.style.display = "block";
        this.listButtonsArea.style.display = "none";
        this.blurTitle(this.titleIdx);
        this.unselectTitle(this.titleIdx);
        if (mgr.hasArticles()) {
            document.getElementById("UICategoryScrollBar").style.display = "block";        
            this.displayArticles(mgr.getArticles().slice(this.startIdx, this.arrTitles.length - 1));            
            this.updateScrollbar(mgr);
            if (!this.hasUne) {
                this.titleIdx = 1;
            }
        } else {
            //widgetAPI.putInnerHTML(document.getElementById("UICategory_btn1"), "<br />Aucun article disponible");
            widgetAPI.putInnerHTML(document.getElementById("UICategory_loading"), "<br />Aucun article disponible");    
            this.listArticlesArea.style.display = "none";
            this.listButtonsArea.style.display = "none";                    
            document.getElementById("UICategoryScrollBar").style.display = "none";
        }
        this.highlightTitle(this.titleIdx);
    } else {
        document.getElementById("UICategory_loading").style.display = "none";
        this.listButtonsArea.style.display = "block";    
        this.listArticlesArea.style.display = "none";
        document.getElementById("UICategoryScrollBar").style.display = "none";
        this.blurButton(this.buttonIdx);
        this.unselectButton(this.buttonIdx);
        this.displayButtons(DataMgr.getChildrenCategories(mgr.getId()));        
        if (!this.hasUne) {
            this.buttonIdx = 1;
        }
        this.highlightButton(this.buttonIdx);
    }
}

UICategory.updateScrollbar = function() {
    var total = DataMgr.getCategory().getNbArticles();
    var cssTop = 0;
    var idx = this.startIdx + this.titleIdx - 1;
    if (idx < 0) {
        idx = 0;
    }
    if (total > 0) {
        var cssTop = Math.floor(idx * 225 / (total - 1));
    }
     if (cssTop == 0) {cssTop = -5;}
    if(Define.debugFlag) alert("UICategory.updateScrollbar -> " + cssTop + "px");
    document.getElementById("UICategoryScrollBead").style.top = cssTop + "px";
}

UICategory.show = function() {
    if(Define.debugFlag) alert("UICategory.show()");
    this.clean();
    this.showLoading();
    this.displayTitle(DataMgr.getCategory().getTitle());
    this.listArea.style.display = "block";
    KeyHandler.focusToCategory();
    this.updateScrollbar();
    if(Define.debugFlag) alert("UICategory.show() End");
}

UICategory.showLoading = function() {
    if(Define.debugFlag) alert("UICategory.showLoading()");
    //widgetAPI.putInnerHTML(document.getElementById("UICategory_btn1"), "<br />Chargement en cours...");
    widgetAPI.putInnerHTML(document.getElementById("UICategory_loading"), "<br />Chargement en cours...");    
    this.listArticlesArea.style.display = "none";
    this.listButtonsArea.style.display = "none";        
    document.getElementById("UICategoryScrollBar").style.display = "none";    
}

UICategory.hide = function() {
    if(Define.debugFlag) alert("UICategory.hide()");
    this.listArea.style.display = "none";
    KeyHandler.focusToKeyBlocker();		// block remote controller key event
}

UICategory.hideFooter = function() {
    if(Define.debugFlag) alert("UICategory.hideFooter()");
    document.getElementById('UICategoryFooter').src = "Resource/image/footer-empty.png";
    //document.getElementById('UICategoryFooter').src = "Resource/image/Navbar_OSD_left.png";
}

UICategory.showFooter = function() {
    if(Define.debugFlag) alert("UICategory.showFooter()");
    document.getElementById('UICategoryFooter').src = "Resource/image/footer.png";
}

UICategory.getHighlightedArticle = function() {
    if (this.titleIdx > 0) {
        return this.titleIdx - 1;
    }
    return -1;
}

UICategory.getHighlightedButton = function() {
    
    if (this.buttonIdx > 0) {
        switch(NewsController.arrPathSub.length) {
            case 1 :
                return this.buttonIdx - 1 + DataMgr.getStartSubFoot();
            case 2 :
                if(DataMgr.getCurrentLigue() == 1) {
                    return this.buttonIdx - 1 + DataMgr.getStartSubLigue1();
                }
                return this.buttonIdx - 1 + DataMgr.getStartSubLigue2();
        }
    }
    return -1;
}

UICategory.setHighlightedArticle = function(idx) {
    this.blurTitle(this.titleIdx);
    this.titleIdx = idx + 1;
    this.highlightTitle(this.titleIdx);
}

UICategory.setHighlightedButton = function(idx) {
    this.blurButton(this.buttonIdx);
    this.buttonIdx = idx + 1;
    this.highlightButton(this.buttonIdx);
}


UICategory.highlightTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.highlightTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_focus";
    }
}

UICategory.highlightButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.highlightButton("+pIndex+")");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className += "_focus";
    }
}

UICategory.blurTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.blurTitle("+pIndex+")");
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UICategory.blurButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.blurButton("+pIndex+")");
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    classe = classe.replace(reg,"");
    this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className = classe;
}

UICategory.selectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.selectTitle(" + pIndex + ")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_selected");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_selected";
    }
}

UICategory.selectButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.selectButton(" + pIndex + ")");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    var index = classe.indexOf("_selected");
    if(index == -1) {
         this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className += "_selected";
    }
}

UICategory.unselectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.unselectTitle(" + pIndex + ")");
    var reg=new RegExp("(_selected)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UICategory.unselectButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.unselectButton(" + pIndex + ")");
    var reg=new RegExp("(_selected)", "g");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    classe = classe.replace(reg,"");
    this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className = classe;
}

UICategory.moveUp = function() {
    if(Define.debugFlag) alert("UICategory.moveUp()");
    // already on top, do nothing       
    var mgr = DataMgr.getCategory();
    if(!DataMgr.hasChildrenCategories(mgr.getId())) {    
    
        if(this.onTopArticle()) {
            return false;
        }
    
        if (this.titleIdx == 1 && this.startIdx > 0) {
            // top of list but we just need to update list (without moving selected div)
            this.startIdx--;
            this.displayArticles(DataMgr.getCategory().getArticles().slice(this.startIdx, this.startIdx + this.arrTitles.length - 1));
        } else {
            // move selected div up
            this.blurTitle(this.titleIdx);
            this.titleIdx--;
            this.highlightTitle(this.titleIdx);
         }
         
         // update scrollbar (only if article is selected)
        if (this.titleIdx) {
            this.updateScrollbar();
        }         
    } else {
    
        if(this.onTopButton()) {
            return false;
        }        
    
        if (this.buttonIdx == 1 && this.startIdx > 0) {
            // top of list but we just need to update list (without moving selected div)
            this.startIdx--;
            this.displayButtons(DataMgr.getChildrenCategories(mgr.getId()));
        } else {
            // move selected div up
            this.blurButton(this.buttonIdx);
            this.buttonIdx--;
            this.highlightButton(this.buttonIdx);
         }            
    }
        
    return true;
}

UICategory.moveDown = function() {
    if(Define.debugFlag) alert("UICategory.moveDown()");        
    var mgr = DataMgr.getCategory();
    if(!DataMgr.hasChildrenCategories(mgr.getId())) {            
    
        // already on bottom, do nothing
        if(this.onBottomArticle()) {
            return false;
        }    
    
        if (this.titleIdx == this.arrTitles.length - 1) {
            // bottom of list but we just need to update list
            this.startIdx++;
            this.displayArticles(DataMgr.getCategory().getArticles().slice(this.startIdx, this.startIdx + this.arrTitles.length - 1));
        } else {
            // move selected div down
            this.blurTitle(this.titleIdx);
            this.titleIdx++;
            this.highlightTitle(this.titleIdx);
        }
    } else {
    
        if(this.onBottomButton()) {
            return false;
        }        
    
        if (this.buttonIdx == 1 && this.startIdx > 0) {
            // top of list but we just need to update list (without moving selected div)
            this.startIdx++;
            this.displayButtons(DataMgr.getChildrenCategories(mgr.getId()));
        } else {
            // move selected div down
            this.blurButton(this.buttonIdx);
            this.buttonIdx++;
            this.highlightButton(this.buttonIdx);
         }            
    }    
    
    // update scrollbar
    this.updateScrollbar();
    return true;
}

UICategory.onBottomArticle = function() {
    if(Define.debugFlag) alert("UICategory.onBottomArticle()");
    if ((this.titleIdx + this.startIdx) >= DataMgr.getCategory().getNbArticles()) {
        return true;
    }
}

UICategory.onBottomButton = function() {
    if(Define.debugFlag) alert("UICategory.onBottomButton()");
    if (this.buttonIdx >= DataMgr.getChildrenCategories(DataMgr.getCategory().getId()).length ) {
        return true;
    }
}

UICategory.onTopArticle = function() {
    if(Define.debugFlag) alert("UICategory.onTopArticle()");
    if ((!this.hasUne && this.titleIdx <= 1) || this.titleIdx < 1) {
        return true;
    }
}

UICategory.onTopButton = function() {
    if(Define.debugFlag) alert("UICategory.onTopButton()");
    if ((!this.hasUne && this.buttonIdx <= 1) || this.buttonIdx < 1) {
        return true;
    }
}

