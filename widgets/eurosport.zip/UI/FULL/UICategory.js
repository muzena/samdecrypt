var UICategory = {
    listArticlesArea : null,			//Div articles
    listButtonsArea : null,			//Div buttons
	loadingArea : null,
    arrTitles : new Array(),	// Array of Title Divs
    arrButtons : new Array(), //Array of buttons
    titleIdx : null,				// title index being highlighted
    buttonIdx : null,				// button index being highlighted
    startIdx : null,             // start index of categories list
    contentsAreaFooter : null,         
}

UICategory.create = function() {
    if(Define.debugFlag) alert("UICategory.create()");
    this.listArticlesArea = document.getElementById("UICategoryArticles");
    this.listButtonsArea = document.getElementById("UICategorySubButtons");
	this.loadingArea = document.getElementById("UICategory_loading");
    this.contentsAreaFooter = document.getElementById("globalFooter");
    this.titleIdx = 0;
    this.buttonIdx = 0;
    this.startIdx = 0;
        
    // init categories button
    var parentDivList = document.getElementById("UICategoryListe");
    if (parentDivList) {
        var childListLength = parentDivList.childNodes.length;        
        for (var i=0; i<childListLength; i++) {
            this.arrTitles[i] = document.getElementById("UICategory_btn" + i);
        }
    }
    
    parentDivList = document.getElementById("UICategoryListeButtons");
    if (parentDivList) {
        var childListLength = parentDivList.childNodes.length;
        for (var i=0; i<childListLength; i++) {
            this.arrButtons[i] = document.getElementById("UICategory_sbtn" + i);
        }
    }
    
    if(Define.debugFlag) alert("print 1 UICategory.create() : " + this.arrTitles.length + " articles created" + this.arrTitles);
    if(Define.debugFlag) alert("print 2 UICategory.create() : " + this.arrButtons.length + " buttons created" + this.arrButtons);
}

UICategory.init = function() {
    if(Define.debugFlag) alert("UICategory.init()");
    this.contentsAreaFooter.className = "footerDeplacer";
    this.clean();
    this.titleIdx = 0;
    this.startIdx = 0;
    
    var mgr = DataMgr.getCategory();
    // articles list
	this.loadingArea.style.display = "none";	
	
    if(!DataMgr.hasChildrenCategories(mgr.getId())) {        
        this.blurTitle(this.titleIdx);
        this.unselectTitle(this.titleIdx);
        if (mgr.hasArticles()) {
            this.displayArticles(mgr.getArticles().slice(this.startIdx, this.arrTitles.length));            
            document.getElementById("UICategoryScrollBar").style.display = "block";
            this.updateScrollbar(mgr);
			this.listArticlesArea.style.display = "block";
			this.listButtonsArea.style.display = "none";			
        } else {
            widgetAPI.putInnerHTML(this.loadingArea, "<br />Aucun article disponible");
			this.loadingArea.style.display = "block";
            document.getElementById("UICategoryScrollBar").style.display = "none";
        }
    } else {
        this.listArticlesArea.style.display = "none";
        this.listButtonsArea.style.display = "block";
        document.getElementById("UICategoryScrollBar").style.display = "none";
        this.blurButton(this.buttonIdx);
        this.unselectButton(this.buttonIdx);
        this.displayButtons(DataMgr.getChildrenCategories(mgr.getId()));
        this.highlightButton(this.buttonIdx);
    }
    if(Define.debugFlag) alert("UICategory.init() End");
}

UICategory.clean = function() {
    if(Define.debugFlag) alert("UICategory.clean()");
    this.listArticlesArea.style.display = "none";
    this.listButtonsArea.style.display = "none";        	
	widgetAPI.putInnerHTML(this.loadingArea, "<br />Chargement en cours...");
    this.loadingArea.style.display = "block";
    document.getElementById("UICategoryScrollBar").style.display = "none";
    this.blurButton(this.buttonIdx);
    this.unselectButton(this.buttonIdx);    
    this.blurTitle(this.titleIdx);
    this.unselectTitle(this.titleIdx);    
    for (var i = 0; i < this.arrTitles.length; i++) {
        widgetAPI.putInnerHTML(document.getElementById("UICategory_btn" + i), "");
    }  
    
    for (var i = 0; i < this.arrButtons.length; i++) {
        widgetAPI.putInnerHTML(document.getElementById("UICategory_sbtn" + i), "");
    }  
}

UICategory.displayTitle = function(title) {
    if(Define.debugFlag) alert("UICategory.displayTitle()");
    var titleCategory = document.getElementById('UICategoryTitle');
    if (title && titleCategory) {
        widgetAPI.putInnerHTML(titleCategory, title);
    }
}

UICategory.displayArticles = function(arrData) {
    if(Define.debugFlag) alert("UICategory.displayArticles()");
    if (arrData) {
        for (var i=0; i<arrData.length; i++) {        
            if (this.arrTitles[i] && arrData[i]) {

                var chaine = '<div class="UICategoryArticleText">' + arrData[i].sport_name + (arrData[i].event != "" ?  ' - ' + arrData[i].event : '') +'<br/>'
                                   + '<span class="UICategoryArticleTitle">' + Util.stringFormat(arrData[i].title, 40, "...") + '</span><br/>'
                                   + Util.stringFormat(arrData[i].shortteaser, 100, "...") + '</div>'
                                   + '<img id="UICategoryArticleImage'+ i + '" class="UICategoryArticleImage" src="Resource/image/x.gif">';
                                   
                widgetAPI.putInnerHTML(this.arrTitles[i], chaine);
                document.getElementById("UICategoryArticleImage"+ i).src = arrData[i].image;
            }
        }
    }
    if(Define.debugFlag) alert("UICategory.displayArticles() End");
}

UICategory.displayButtons = function(arrData) {
    if(Define.debugFlag) alert("UICategory.displayButtons()");
    if (arrData) {
        for (var i=0; i<this.arrButtons.length; i++) {
            if (this.arrButtons[i] && arrData[i]) {
                widgetAPI.putInnerHTML(this.arrButtons[i], '<div class="UIButtonSubSmallText">' + arrData[i].getTitle() +  '</div>');
                this.arrButtons[i].style.display = "block";
            } else {
                this.arrButtons[i].style.display = "none";
            }
        }
    }
 //   this.contentsAreaFooter.className = "footer4fleches";
    if(Define.debugFlag) alert("UICategory.displayButtons() End");
}

UICategory.updateFooter4fleches = function() {
    this.contentsAreaFooter.className = "footer4fleches";
}

UICategory.updateScrollbar = function() {
    var total = DataMgr.getCategory().getNbArticles();
    var cssTop = 0;
    var idx = this.startIdx + this.titleIdx;    
    if (idx < 0) {
        idx = 0;
    }
    if (total > 0) {
        var cssTop = Math.floor(idx * 435 / (total - 1));
    }
    if(cssTop == 0) {cssTop = -5;}
    if(Define.debugFlag) alert("UICategory.updateScrollbar -> " + cssTop + "px");
    document.getElementById("UICategoryScrollBead").style.top = cssTop + "px";
  
}

UICategory.getHighlightedArticle = function() {
    return this.titleIdx - 1;
}

UICategory.getHighlightedButton = function() {    
    switch(NewsController.arrPathSub.length) {
        case 1 :
            return this.buttonIdx + DataMgr.getStartSubFoot();
        case 2 :
            if(DataMgr.getCurrentLigue() == 1) {
                return this.buttonIdx + DataMgr.getStartSubLigue1();
            }
            return this.buttonIdx + DataMgr.getStartSubLigue2();
    }
}

UICategory.setHighlightedButton = function(idx) {
    this.blurButton(this.buttonIdx);
    this.buttonIdx = idx + 1;
    this.highlightButton(this.buttonIdx);
}

UICategory.highlightTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.highlightTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_focus";
    }
}

UICategory.highlightButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.highlightButton("+pIndex+")");
    if(pIndex < 0) return;
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className += "_focus";
    }
    UICategory.updateFooter4fleches();
}

UICategory.blurTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.blurTitle("+pIndex+")");
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UICategory.blurButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.blurButton("+pIndex+")");
    if(pIndex < 0) return;
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    classe = classe.replace(reg,"");
    this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className = classe;
}

UICategory.selectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.selectTitle(" + pIndex + ")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_selected");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_selected";
    }
}

UICategory.selectButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.selectButton(" + pIndex + ")");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    var index = classe.indexOf("_selected");
    if(index == -1) {
         this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className += "_selected";
    }
}

UICategory.unselectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.unselectTitle(" + pIndex + ")");
    var reg=new RegExp("(_selected)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UICategory.unselectButton = function(pIndex) {
    if(Define.debugFlag) alert("UICategory.unselectButton(" + pIndex + ")");
    if(pIndex < 0) return;
    var reg=new RegExp("(_selected)", "g");
    var classe = this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className;
    classe = classe.replace(reg,"");
    this.arrButtons[pIndex!=null?pIndex:this.buttonIdx].className = classe;
}

UICategory.moveUp = function() {
    if(Define.debugFlag) alert("UICategory.moveUp()");
    
    var mgr = DataMgr.getCategory();
    if(!DataMgr.hasChildrenCategories(mgr.getId())) {    //navigation article
        
        // already on top, do nothing           
        if(this.onTopArticle()) {
            return false;
        }
    
        if (this.titleIdx == 0 && this.startIdx > 0) {
            // top of list but we just need to update list (without moving selected div)
            this.startIdx--;
            this.displayArticles(DataMgr.getCategory().getArticles().slice(this.startIdx, this.startIdx + this.arrTitles.length));
        } else {
            // move selected div up
            this.blurTitle(this.titleIdx);
            this.titleIdx--;
            this.highlightTitle(this.titleIdx);
         }         
         this.updateScrollbar();
         
    } else {  //navigation bouttons sous catégorie
    
        if(this.onTopButton()) {
            return false;
        }        
    
        if (this.buttonIdx == 0 && this.startIdx > 0) {     
            // top of list but we just need to update list (without moving selected div)
            this.startIdx--;
            this.displayButtons(DataMgr.getChildrenCategories(mgr.getId()));
        } else {
            // move selected div up
            this.blurButton(this.buttonIdx);
            this.buttonIdx--;
            this.highlightButton(this.buttonIdx);
         }            
    }
     
    return true;
}

UICategory.moveDown = function() {
    if(Define.debugFlag) alert("UICategory.moveDown()");        
    var mgr = DataMgr.getCategory();
    if(!DataMgr.hasChildrenCategories(mgr.getId())) {            
    
        // already on bottom, do nothing
        if(this.onBottomArticle()) {
            return false;
        }    
    
        if (this.titleIdx == this.arrTitles.length - 1) {
            // bottom of list but we just need to update list
            this.startIdx++;
            this.displayArticles(DataMgr.getCategory().getArticles().slice(this.startIdx, this.startIdx + this.arrTitles.length));
        } else {
            // move selected div down
            this.blurTitle(this.titleIdx);
            this.titleIdx++;
            this.highlightTitle(this.titleIdx);
        }
    } else {
    
        if(this.onBottomButton()) {
            return false;
        }        
    
        if (this.buttonIdx == 0 && this.startIdx > 0) {
            // top of list but we just need to update list (without moving selected div)
            this.startIdx++;
            this.displayButtons(DataMgr.getChildrenCategories(mgr.getId()));
        } else {
            // move selected div down
            this.blurButton(this.buttonIdx);
            this.buttonIdx++;
            this.highlightButton(this.buttonIdx);
         }            
    }
    
    // update scrollbar
    this.updateScrollbar();
    return true;
}

UICategory.calculatePosition = function(positionPushed){
    if(Define.debugFlag) alert("UICategory.calculatePosition("+positionPushed+")");
    if(Define.debugFlag) alert("buttonIdx => " + this.buttonIdx);
    var next = 0;
    var back = false;

    switch (positionPushed) {
            case NewsController.CATEGORY_UP:
                    next = this.buttonIdx - 3;
                    back = false;
                    break;      
            
            case NewsController.CATEGORY_DOWN:
                    next = this.buttonIdx + 3;
                    back = false;
                    break;     
            
            case NewsController.CATEGORY_LEFT:
                    next = this.buttonIdx - 1;
                    back = true;
                    break;      
            
            case NewsController.CATEGORY_RIGHT:
                    next = this.buttonIdx + 1;
                    back = false;
                    break;   
    }
    
    if(next > (DataMgr.getChildrenCategories(DataMgr.getCategory().getId()).length - 1)) {
            return;
    }
    
    if( positionPushed == NewsController.CATEGORY_LEFT && this.buttonIdx == 3 && next == 2 ) {
            next = -1;
    }
       
    if(next < 0 && DataMgr.getCategory().hasParentRubrique() == null) {
    
        if(back === false) {
            return;
        }
    
        this.blurTitle(this.titleIdx);
        this.blurButton(this.buttonIdx);
        UIHome.unselectTitle(UIHome.titleIdx);        
        UIHome.highlightTitle(UIHome.titleIdx);
        UIHome.show();
        DataMgr.setCurrentLigue(0);
        return;
    }else if(next < 0) return;
    
    this.blurButton(this.buttonIdx);
    this.buttonIdx = next;
    this.highlightButton(this.buttonIdx);
    if(Define.debugFlag) alert("UICategory.calculatePosition() End");    
}

UICategory.onBottomArticle = function() {
    if(Define.debugFlag) alert("UICategory.onBottomArticle()");
    if ((this.titleIdx + this.startIdx) >= DataMgr.getCategory().getNbArticles() - 1) {
        return true;
    }
}

UICategory.onBottomButton = function() {
    if(Define.debugFlag) alert("UICategory.onBottomButton()");
    if (this.buttonIdx >= DataMgr.getChildrenCategories(DataMgr.getCategory().getId()).length - 1) {
        return true;
    }
}

UICategory.onTopArticle = function() {
    if (this.startIdx == 0 && this.titleIdx == 0 ) {
        return true;
    }
}

UICategory.onTopButton = function() {
    if(Define.debugFlag) alert("UICategory.onTopButton()");
    if (this.buttonIdx == 0) {
        return true;
    }
}

UICategory.hideArticleListe = function() {
    if(Define.debugFlag) alert("UICategory.hideArticleListe()");
    document.getElementById("UICategoryArticles").style.display = "none";
}

UICategory.showArticleListe= function() {
    if(Define.debugFlag) alert("UICategory.showArticleListe()");
    document.getElementById("UICategoryArticles").style.display = "block";
}

UICategory.hideSubListe = function() {
    if(Define.debugFlag) alert("UICategory.hideSubListe()");
    document.getElementById("UICategorySubButtons").style.display = "none";
}

UICategory.showSubListe= function() {
    if(Define.debugFlag) alert("UICategory.showSubListe()");
    document.getElementById("UICategorySubButtons").style.display = "block";
}