var UIError= {
    element : null,	
    theTitle : null,	
    Msg : null,	
    ButtonMsg : null,	
    tvKey : null
}

UIError.create = function() {
        this.element = document.getElementById("UIErrorMessage"); 
        this.theTitle = document.getElementById("UIErrorTitle"); 
        this.Msg = document.getElementById("UIErrorBody"); 
        this.ButtonMsg = document.getElementById("UIErrorbutton"); 
        this.tvKey = new Common.API.TVKeyValue();
}

UIError.showTechnicalError = function() {

         var  linkUrl = "<a href='javascript:void(0);' id='popupError_Anchor' onkeydown='UIError.TechnicalHandler()'></a>";
        
        widgetAPI.putInnerHTML( this.theTitle,"Problème technique");
        widgetAPI.putInnerHTML(this.ButtonMsg,"Fermer l'application");
        widgetAPI.putInnerHTML( this.Msg,"Un problème technique est survenu. Veuillez nous excuser de la gêne occasionnée " + linkUrl);
         this.element.className = "UIErrorMessageShow";
         document.getElementById("popupError_Anchor").focus();
}

UIError.showNetworklError = function() {
       alert("showNetworklError");
       
       var  linkUrl = "<a href='javascript:void(0);' id='popupError_Anchor' onkeydown='UIError.NetworkHandler()'></a>";
       widgetAPI.putInnerHTML( this.theTitle,"Problème réseau");
       widgetAPI.putInnerHTML(this.ButtonMsg,"Fermer l'application");
       widgetAPI.putInnerHTML( this.Msg,"Un problème de connexion au réseau a été détecté et empêche le bon fonctionnement de l'application" + linkUrl);
       this.element.className = "UIErrorMessageShow";
       document.getElementById("popupError_Anchor").focus();
}

UIError.hide = function() {
    this.element.className = "UIErrorMessageHide";
}

UIError.NetworkHandler = function() {
    var popupKeyCode = event.keyCode;

    alert("UIError  KeyCode = " + popupKeyCode);
    
    switch(popupKeyCode) {
        case this.tvKey.KEY_RETURN:
        case this.tvKey.KEY_EXIT:
        case this.tvKey.KEY_ENTER:              
                   widgetAPI.blockNavigation(event);
                widgetAPI.sendReturnEvent();
        break;
    }
}

UIError.TechnicalHandler = function() {
    var popupKeyCode = event.keyCode;

    alert("UIError  KeyCode = " + popupKeyCode);
    
    switch(popupKeyCode) {
        case this.tvKey.KEY_RETURN:
        case this.tvKey.KEY_EXIT:
        case this.tvKey.KEY_ENTER:
                widgetAPI.blockNavigation(event);
                widgetAPI.sendReturnEvent();
        break;
    }
}