var UIHome = {
    listArea : null,			// UIList Div
    arrTitles : new Array(),	// Array of Title Divs
    titleIdx : null				// title index being highlighted
}

UIHome.create = function() {
    if(Define.debugFlag) alert("UIHome.create()");
    this.listArea = document.getElementById("UIHome");
    this.titleIdx = Define.homeDefaultSelected;
        
    this.arrTitles[0] = document.getElementById("UIHome_btn0");
}

UIHome.init = function() {
    if(Define.debugFlag) alert("UIHome.init()");
    this.displayCategories();
    NewsController.homeToCategory(false);
    NewsController.anyCategoryBack();
	UICategory.clean();
}

UIHome.displayCategories = function() {
    // display categories
    if(Define.debugFlag) alert("UIHome.displayCategories()");
    if (DataMgr.hasCategories()) {
        var buttonsHtml = '';
        for (var i=0; i < DataMgr.arrCategoryList.length; i++)  {
            if(!DataMgr.arrCategoryList[i].hasParentRubrique()) {                
                buttonsHtml += '<div id="UIHome_btn' + (i + 1) + '" class="UIButton"><div class="UIButtonText">' + DataMgr.arrCategoryList[i].getTitle() + '</div></div>';
            }
       }       
       widgetAPI.putInnerHTML(document.getElementById("UIHomePart1"), buttonsHtml);

       for (var i=1; i < DataMgr.arrCategoryList.length + 1; i++) {
            if(!DataMgr.arrCategoryList[i-1].hasParentRubrique()) {                
                this.arrTitles[i] = document.getElementById("UIHome_btn"+i);
            }
        }
                
        // highlight selected
        this.highlightTitle(this.titleIdx);
    } else {
        widgetAPI.putInnerHTML(document.getElementById("UIHomePart1"), "<br />Aucune catégorie disponible");
        this.highlightTitle(0);
    }
}

UIHome.show = function() {
    if(Define.debugFlag) alert("UIHome.show()");
    this.listArea.style.display = "block";
    KeyHandler.focusToHome();
}

UIHome.hide = function() {
    if(Define.debugFlag) alert("UIHome.hide()");
    this.listArea.style.display = "none";
    KeyHandler.focusToKeyBlocker();		// block remote controller key event
}

UIHome.getHighlightedCategory = function() {
    if (this.titleIdx > 0) {
        return this.titleIdx - 1;
    }
    return -1;
}

UIHome.highlightTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.highlightTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    var index = classe.indexOf("_focus");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_focus";
    }
}

UIHome.blurTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.blurTitle("+pIndex+")");
    var reg=new RegExp("(_focus)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;    
    classe = classe.replace(reg,"");    
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UIHome.selectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.selectTitle("+pIndex+")");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;    
    var index = classe.indexOf("_selected");
    if(index == -1) {
         this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className += "_selected";
    }
}

UIHome.unselectTitle = function(pIndex) {
    if(Define.debugFlag) alert("UIHome.unselectTitle("+pIndex+")");
    var reg=new RegExp("(_selected)", "g");
    var classe = this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className;
    classe = classe.replace(reg,"");
    this.arrTitles[pIndex!=null?pIndex:this.titleIdx].className = classe;
}

UIHome.moveUp = function() {
    if(Define.debugFlag) alert("UIHome.moveUp()");
    if (DataMgr.hasCategories() && this.titleIdx != 1) {
        this.blurTitle(this.titleIdx);
        if (this.titleIdx <= 0) {
            this.titleIdx = this.arrTitles.length - 1;
            UIFilnews.hide();        
        } else {
            this.titleIdx--;
        }
        this.highlightTitle(this.titleIdx);       

        NewsController.homeToCategory(false);      
        NewsController.anyCategoryBack();
		UICategory.clean();
     }
    if(Define.debugFlag) alert("UIHome.moveUp() End");
}

UIHome.moveDown = function() {
    if(Define.debugFlag) alert("UIHome.moveDown()");
    if (DataMgr.hasCategories() && this.titleIdx) {
        this.blurTitle(this.titleIdx);
        if (this.titleIdx >= this.arrTitles.length - 1) {
            this.titleIdx = 0;
        } else {
            this.titleIdx++;
        }
        this.highlightTitle(this.titleIdx);        

        
        //permettre le onChange (sauf sur filnews)
        if(UIHome.titleIdx != 0) {
            NewsController.homeToCategory(false);
            NewsController.anyCategoryBack();
			UICategory.clean();
        } else {       
        
            UICategory.hideArticleListe();       
			NewsController.homeToFilnews();
            NewsController.filnewsBack();
            
       }		
     }
     if(Define.debugFlag) alert("UIHome.moveDown() End");
}