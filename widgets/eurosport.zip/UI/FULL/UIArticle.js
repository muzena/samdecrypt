var UIArticle = {
    listArea : null,
    divTextStyleTop : null,
    titleElt : null,
    detailsElt : null,
    chapoElt : null,
    textElt : null,
    imageElt : null,
    contentElt : null,
    innerArticleContentElt : null,
    scrollBarElt : null,
    scrollBeadElt : null,
    nbScrollHits : null,
    scrollable : null,
    scrollSize : 40
}

/* ===================================================== */
/* 1) initialise les éléments de la div ARTICLE (champ, scrollbar, position début) */
/* ===================================================== */
UIArticle.create = function() {
    if(Define.debugFlag) alert("UIArticle.create()");
    this.listArea = document.getElementById("UIArticle");
    this.titleElt = document.getElementById("UIArticleTitle");
    this.detailsElt = document.getElementById("UIArticleDetails");
    this.chapoElt = document.getElementById("UIArticleChapo");
    this.textElt = document.getElementById("UIArticleText");
    this.imageElt = document.getElementById("UIArticleImage");
    this.contentElt = document.getElementById("UIArticleContent");
    this.innerArticleContentElt = document.getElementById("UIArticleInnerContent");
    this.scrollBarElt = document.getElementById("UIArticleScrollbar");
    this.scrollBeadElt = document.getElementById("UIArticleScrollBead");
    this.footer = document.getElementById("globalFooter");
    this.divTextStyleTop = 0;
    this.nbScrollHits = 0;
    this.scrollable = true;
    this.scrollBeadElt.style.display = "none";
    this.scrollBarElt.style.display = "none";
}


/* ===================================================== */
/* 2.1 ) écrit un contenu de type article dans la div ARTICLE                                 */
/* ===================================================== */
UIArticle.displayArticle = function(arrData) {
    if(Define.debugFlag) alert("UIArticle.displayArticle()");
    if (arrData) {
 this.contentElt.style.top = "10px";
        this.scrollBarElt.style.top = "10px";                    
        this.contentElt.style.height = "425px";         
        this.scrollBarElt.style.height = "425px";
        this.textElt.style.top = "178px";
        this.detailsElt.style.display = "block";
        this.chapoElt.style.display = "block";    
        if (arrData.name) {
            //widgetAPI.putInnerHTML(this.titleElt, arrData.name);
            widgetAPI.putInnerHTML(this.titleElt, Util.stringFormat(arrData.name, 49, "..."));                        
        }
        if (arrData.details) {
            //widgetAPI.putInnerHTML(this.detailsElt, arrData.details);
            widgetAPI.putInnerHTML(this.detailsElt, Util.stringFormat(arrData.details, 60, "..."));                        
        }
        if (arrData.image) {
            this.imageElt.src = arrData.image;
        } else {
            this.imageElt.src = Define.imageNotFound;
        }
        if (arrData.longteaser) {
            widgetAPI.putInnerHTML(this.chapoElt, arrData.longteaser);
        }
        if (arrData.text) {
            widgetAPI.putInnerHTML(this.textElt, arrData.text);
        }
    }    
}

/* ===================================================== */
/* 2.2) écrit un contenu de type Résultat de Ligue dans la div ARTICLE           */
/* ===================================================== */
UIArticle.displayResultats = function(results, articleMgrId) {
 this.contentElt.style.top = "10px";
        this.scrollBarElt.style.top = "10px";                    
        this.contentElt.style.height = "425px";         
        this.scrollBarElt.style.height = "425px";
    this.textElt.style.top = "65px";               
    this.detailsElt.style.display = "none";
    this.chapoElt.style.display = "none";
                        
    var dateJournee = results[0]["date"];                    
    widgetAPI.putInnerHTML(this.titleElt, "Résultats de "+results[0]["round"]+" de Ligue " + (articleMgrId == IDMgr.getInfo("ligue1Res") ? "1":"2"));

    var chaine = "";                  
    chaine += "<div class=\"UIResultatDate\">"+ Util.dayOf(dateJournee) +"</div><table>";
    for(var i = 0 ; i< results.length; i++) {
        if(dateJournee != results[i]["date"]) {                            
            dateJournee = results[i]["date"];
            if(i > 0) chaine += "</table><br/>";
            chaine += "<div class=\"UIResultatDate\">"+ Util.dayOf(dateJournee) +"</div><table>";
        }
        chaine += "<tr><td class= \"UIResultatTeam\" style=\"text-align:right;\">" + results[i]["team1"] + "</td>" 
                     + "<td class=\"UIResultatScore\">" + results[i]["score1"] + "&nbsp;&nbsp;-&nbsp;&nbsp;" + results[i]["score2"] + "</td>" 
                     + "<td class= \"UIResultatTeam\">" + results[i]["team2"] + "</td></tr>";                                        
    }                    
    chaine +="<br/><br/><br/><br/><br/><br/>"; // Pour etre sur de declencher la scrollbar si la page est limite
    widgetAPI.putInnerHTML(this.textElt, chaine);
}

/* ===================================================== */
/* 2.3) écrit un contenu de type Calendrier de Ligue dans la div ARTICLE       */
/* ===================================================== */
UIArticle.displayCalendrier = function(calendrier, articleMgrId) {
 this.contentElt.style.top = "10px";
        this.scrollBarElt.style.top = "10px";                    
        this.contentElt.style.height = "425px";         
        this.scrollBarElt.style.height = "425px";
    this.textElt.style.top = "65px";  
    this.detailsElt.style.display = "none";
    this.chapoElt.style.display = "none";
    
    var dateJournee = calendrier[0]["date"];
                        
    //widgetAPI.putInnerHTML(this.titleElt, "Calendrier de la prochaine journ&eacute;e de Ligue " + (articleMgrId== IDMgr.getInfo("ligue1Cal") ? "1":"2"));
    widgetAPI.putInnerHTML(this.titleElt, "Calendrier de la "+ calendrier[0]["round"] +" de Ligue " + (articleMgrId== IDMgr.getInfo("ligue1Cal") ? "1":"2"));    
    var chaine = "";
    chaine += "<div class=\"UIResultatDate\">"+ Util.dayOf(dateJournee) +"</div><table>";
    for(var i = 0 ; i< calendrier.length; i++) {
        if(dateJournee != calendrier[i]["date"]) {                            
            dateJournee = calendrier[i]["date"];
            if(i > 0) chaine += "</table><br/>";
            chaine += "<div class=\"UIResultatDate\">"+ Util.dayOf(dateJournee) +"</div><table>";
        }
        chaine += "<tr><td class= \"UIResultatTeam\" style=\"text-align:right;\">" + calendrier[i]["team1"] + "</td>" 
                     + "<td class=\"UIResultatScore\">" + calendrier[i]["time"] + "</td>" 
                     + "<td class= \"UIResultatTeam\">" + calendrier[i]["team2"] + "</td></tr>";                                        
    }
    chaine +="<br/><br/><br/><br/><br/><br/>"; // Pour etre sur de declencher la scrollbar si la page est limite
    widgetAPI.putInnerHTML(this.textElt, chaine);
}

/* ===================================================== */
/* 2.4) écrit un contenu de type Classement de Ligue dans la div ARTICLE               */
/* ===================================================== */
UIArticle.displayClassement = function(classement, articleMgrId) {
 this.contentElt.style.top = "10px";
        this.scrollBarElt.style.top = "10px";                    
        this.contentElt.style.height = "425px";         
        this.scrollBarElt.style.height = "425px";
    this.textElt.style.top = "65px";  
    this.detailsElt.style.display = "none";
    this.chapoElt.style.display = "none";       
    
    widgetAPI.putInnerHTML(this.titleElt, "Classement de la Ligue " + (articleMgrId == IDMgr.getInfo("ligue1Class") ? "1":"2"));
    
    var chaine = "<table><tr>"
                       + "<th>&nbsp;</th>"
                       + "<th>&nbsp;</th>"
                       + "<th class=\"UIClassementTh\">Pts</th>"
                       + "<th class=\"UIClassementTh\">J</th>"
                       + "<th class=\"UIClassementTh\">G</th>"
                       + "<th class=\"UIClassementTh\">N</th>"
                       + "<th class=\"UIClassementTh\">P</th>"
                       + "<th class=\"UIClassementTh\">bp</th>"
                       + "<th class=\"UIClassementTh\">bc</th>"
                       + "<th class=\"UIClassementTh\">diff.</th>"
                       + "</tr>";

    for(var i = 0 ; i< classement.length; i++) {
        chaine += "<tr><td class=\"UIClassementTdPosition\">" + classement[i]["position"] + "</td>" 
                     + "<td class=\"UIClassementTdTeam\">" + classement[i]["team"] + "</td>" 
                     + "<td class=\"UIClassementTdBlue\">" + classement[i]["pts"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["J"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["G"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["N"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["P"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["bp"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["bc"] + "</td>"
                     + "<td class=\"UIClassementTd\">" + classement[i]["diff"] + "</td>"
                     + "</tr>";                                        
    }
    chaine += "</table>";
    chaine +="<br/><br/><br/><br/><br/><br/>"; // Pour etre sur de declencher la scrollbar si la page est limite
    widgetAPI.putInnerHTML(this.textElt, chaine);
}

/* ===================================================== */
/* 3) prépare le contenu de la div ARTICLE en fonction du type de contenu à afficher (res, cal, classement, actu)... cf. Méthodes 2.1) - 2.2) - 2.3) - 2.4) */
/* ===================================================== */
UIArticle.init = function() {
    if(Define.debugFlag) alert("UIArticle.init()");
    this.clean();
    this.resetTextPosition();
    var articleMgr = DataMgr.getArticle();    

    if(articleMgr) {
        switch(articleMgr.getType()) {                
            case Define.typeResultats :
                var results = articleMgr.getResultats();
                if(results) {
                    this.displayResultats(results, articleMgr.getId());
                    this.updateScrollbar();
                } else {
                    widgetAPI.putInnerHTML(this.titleElt, "R&eacute;sultats non disponible");
                }
                break;
                
            case Define.typeCalendrier :
                var calendrier = articleMgr.getCalendrier();                            
                if(calendrier) {
                    this.displayCalendrier(calendrier, articleMgr.getId());
                    this.updateScrollbar();
                } else {
                    widgetAPI.putInnerHTML(this.titleElt, "Calendrier non disponible");
                }
                break;

            case Define.typeClassement :
                var classement = articleMgr.getClassement();                            
                if(classement) {
                    this.displayClassement(classement, articleMgr.getId());
                    this.updateScrollbar();
                } else {
                    widgetAPI.putInnerHTML(this.titleElt, "Classement non disponible");
                }                    
                break;                
            case Define.typeArticle :
                var article = articleMgr.getArticle();
                if (article) {
                    this.displayArticle(article);
                    this.updateScrollbar();
                } else {
                    widgetAPI.putInnerHTML(this.titleElt, "Article non disponible");
                }
                break;                
                
            default :            
        }
    }
    this.updateScrollbar();
}

/* ===================================================== */
/* 4) Méthodes de gestion d'affichage du contenu ARTICLE (show, hide, load, clean) */
/* ===================================================== */
UIArticle.clean = function() {
    if(Define.debugFlag) alert("UIArticle.clean()");
    widgetAPI.putInnerHTML(this.titleElt, "");
    widgetAPI.putInnerHTML(this.detailsElt, "");
    widgetAPI.putInnerHTML(this.chapoElt, "");
    widgetAPI.putInnerHTML(this.textElt, "");
    this.detailsElt.style.display = "none";
    this.chapoElt.style.display = "none";    
    this.imageElt.src = "Resource/image/x.gif";
}

UIArticle.show = function() {
    if(Define.debugFlag) alert("UIArticle.show()");
    this.resetTextPosition();
    this.showLoading();
    this.listArea.style.display = "block";
    
    this.divTextStyleTop = 0;
    this.nbScrollHits = 0;
    this.scrollable = true;
    this.scrollBeadElt.style.display = "none";
    this.scrollBarElt.style.display = "none";
    UICategory.hideArticleListe();
    KeyHandler.focusToArticle();
}

UIArticle.showLoading = function() {
    if(Define.debugFlag) alert("UIArticle.showLoading()");
    widgetAPI.putInnerHTML(this.titleElt, "Chargement en cours...");
    widgetAPI.putInnerHTML(this.detailsElt, "");
    widgetAPI.putInnerHTML(this.chapoElt, "");
    widgetAPI.putInnerHTML(this.textElt, "");
    this.detailsElt.style.display = "none";    
    this.imageElt.src = "Resource/image/x.gif";
}

UIArticle.hide = function() {
    if(Define.debugFlag) alert("UIArticle.hide()");
    this.listArea.style.display = "none";
    this.footer.className = "footerDeplacer";
    UICategory.showArticleListe();
    switch(NewsController.currentState) {
        case NewsController.UIHOME:        
            KeyHandler.focusToHome();
            break;
        case NewsController.UISUBCATEGORY:            
        case NewsController.UICATEGORY:
            KeyHandler.focusToCategory();
            break;
        default:
            KeyHandler.focusToKeyBlocker();		// block remote controller key event
    }
}


/* ===================================================== */
/* 5) Méthodes de gestion de position de scrollbar                                      */
/* ===================================================== */
UIArticle.resetTextPosition = function() {
    this.divTextStyleTop = 0;
    this.innerArticleContentElt.style.top = this.divTextStyleTop + "px";
    this.scrollBeadElt.style.top = "-5px";
}

UIArticle.updateScrollbar = function() {              

    if(this.textElt.offsetHeight > 0 && this.nbScrollHits == 1) {
        var minTop = this.contentElt.offsetHeight - this.chapoElt.offsetHeight - this.textElt.offsetHeight - Define.articleScrollPixels - this.scrollSize;  
      
      if(this.divTextStyleTop - Define.articleScrollPixels < minTop) {
            this.scrollBeadElt.style.display = "none";
            this.scrollBarElt.style.display = "none";
            this.scrollable = false;
            this.footer.className = "footerLight";
        }else {
            this.scrollBeadElt.style.display = "block";
            this.scrollBarElt.style.display = "block";    
            this.scrollable = true;
            this.footer.className = "footerDeplacer";
        }        
    }
    
    var cssTop = Math.floor(this.divTextStyleTop * (this.scrollBarElt.offsetHeight - this.scrollBeadElt.offsetHeight +5) / (this.contentElt.offsetHeight - this.scrollSize -  this.chapoElt.offsetHeight - this.textElt.offsetHeight - Define.articleScrollPixels));
    if(Define.debugFlag) alert("UIArticle.updateScrollbar | " + cssTop + "px");
    if(cssTop == 0) {cssTop = -5;}
    this.scrollBeadElt.style.top = cssTop + "px";    
    this.nbScrollHits++;
}

UIArticle.moveUp = function() {
    if(Define.debugFlag) alert("UIArticle.moveUp()");
    this.divTextStyleTop += Define.articleScrollPixels;
    if (this.divTextStyleTop > 0) {
        this.divTextStyleTop = 0;
    }
    this.innerArticleContentElt.style.top = this.divTextStyleTop + "px";
    this.updateScrollbar();
}

UIArticle.moveDown = function() {
    if(Define.debugFlag) alert("UIArticle.moveDown()");

    var minTop = this.contentElt.offsetHeight - this.chapoElt.offsetHeight - this.textElt.offsetHeight - Define.articleScrollPixels  - this.scrollSize;
    if(Define.debugFlag) alert("UIArticle.moveDown()");
    if (minTop > 0 || !this.scrollable) {
        return;
    }
    else { //correction
        this.divTextStyleTop -= Define.articleScrollPixels;
    }
    if (this.divTextStyleTop < minTop) {
        this.divTextStyleTop = minTop;
    }    
    this.innerArticleContentElt.style.top = this.divTextStyleTop + "px";
    this.updateScrollbar();    
}